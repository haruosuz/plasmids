library(ape)
library(ggtree)
library(Biostrings)
library(phangorn)
library(ggplot2)

# File paths
tree_file <- "../myAlign_iqtree_rev.treefile"
fasta_file <- "../../myAA.fasta"
pdf_output <- "my_ggtree_labeled.pdf"

# Read and format the tree
tree <- read.tree(tree_file)
mytree <- phangorn::midpoint(tree)
mytree <- ladderize(mytree, right = TRUE)

# Map accession numbers to labels from the FASTA file
fasta_seqs <- readAAStringSet(fasta_file)
headers <- names(fasta_seqs)
accession_to_label <- setNames(headers, sub(" .*", "", headers))

# Replace tip labels with the full header names
mytree$tip.label <- sapply(mytree$tip.label, function(x) {
  if (x %in% names(accession_to_label)) {
    accession_to_label[[x]]
  } else {
    x
  }
})

# Create the ggtree object
p <- ggtree(mytree)

# Extract data and check for internal node labels
d <- p$data
if (!"label" %in% colnames(d)) {
  d$label <- ""
}

# Output to PDF
pdf(pdf_output, pointsize = 10, width =15, height = 9)

# Create the plot
p + 
  geom_tiplab(size = 2, hjust = 1, nudge_x = 0.5, nudge_y = 0.2) +  # Increase the font size of tip labels
  geom_text2(data = d[d$isTip == FALSE & !is.na(as.numeric(d$label)), ],
             aes(label = label),
             hjust = -0.3, size = 2) +  # Increase the font size of support values
  geom_treescale(x = 0, y = 0, width = 0.5) +
  theme_tree2() + scale_x_continuous(breaks = 0:5) + 
  theme(plot.margin = margin(1, 1, 1, 3, "cm"))  # Adjust the right margin to avoid cutting off labels

dev.off()

sessionInfo()
