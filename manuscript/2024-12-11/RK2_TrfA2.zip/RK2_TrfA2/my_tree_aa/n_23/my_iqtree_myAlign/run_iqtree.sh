#!/bin/bash
set -e
set -u
set -o pipefail
#set -euo pipefail

# start
echo; echo "[$(date)] $0 job has been started."

# activate the virtual environment
#source ${HOME}/tools/venv_jlsteenwyk/bin/activate

# https://github.com/haruosuz/introBI/blob/main/2024-04/README.md#variables-and-command-arguments
iqtree="${HOME}/tools/my_iqtree/iqtree-2.3.4-macOS/bin/iqtree2"

alignment=$1
prefix=$(basename ${alignment} .fasta)_iqtree

echo; echo '# IQ-TREE: Efficient phylogenomic software by maximum likelihood'
echo 'http://www.iqtree.org/'
echo 'http://www.iqtree.org/doc/Quickstart'
"${iqtree}" -version

# http://www.iqtree.org/doc/Tutorial#assessing-branch-supports-with--standard-nonparametric-bootstrap
#"${iqtree}" -s ${alignment} --prefix "${prefix}_rev" -T AUTO -m MFP -b 100

# http://www.iqtree.org/doc/Tutorial#assessing-branch-supports-with-ultrafast-bootstrap-approximation
"${iqtree}" -s ${alignment} --prefix "${prefix}_rev" -T AUTO -m MFP --ufboot 1000

# http://www.iqtree.org/doc/Tutorial#assessing-branch-supports-with-single-branch-tests
#"${iqtree}" -s ${alignment} --prefix "${prefix}_rev" -T AUTO -m MFP --ufboot 1000 -alrt 1000

# http://www.iqtree.org/doc/Rootstrap
#"${iqtree}" -s "${alignment}" --prefix "${prefix}_nonrev" -T AUTO --ufboot 1000 --model-joint NONREV --root-test -zb 1000 -au

# http://www.iqtree.org/doc/Assessing-Phylogenetic-Assumptions
"${iqtree}" -s "${alignment}" --prefix "${prefix}_symtest" -T AUTO --symtest-only

# done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

# Usage:
(bash run_iqtree.sh &) >& log.iqtree.$(date +%F).txt
tail -f log.iqtree.$(date +%F).txt

#__COMMENT_OUT__
