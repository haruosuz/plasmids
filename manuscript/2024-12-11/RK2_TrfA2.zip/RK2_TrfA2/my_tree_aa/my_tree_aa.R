#' ---
#' title: "Inferring Phylogenetic Trees"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      theme: united
#'      highlight: tango
#'      toc: true
#' ---
#' 
# Clear R's environment
rm(list = ls())

# Load the required packages
#+ warning = FALSE
#+ message = FALSE
library(Peptides)
library(rentrez)
library(seqinr)
library(ape)
library(phangorn)
library(phytools)
library(microseq)
library(Biostrings)
library(DECIPHER)
library(ggseqlogo)
library(tidyverse)

# parameters
mycex <- 1.00 # Graphical Parameters
#par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1.5, 0.5, 1, 0.5), cex=mycex) # c(bottom, left, top, right)
database <- "ncbi_protein"
#database <- "uniprot"
#' - https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html
UPGMA_NJ <- "UPGMA"
UPGMA_NJ <- "NJ"
# ?phangorn::dist.ml 
mymodel <- "WAG" # "WAG", "JTT", "LG", "Dayhoff", , "Blosum62", ,
myexclude <- "pairwise" # "none", "all", "pairwise"

#' # Acquiring the Sequences
file.fasta <- "myAA.fasta" # FASTA file of protein (amino acid) sequences
download <- ifelse(!file.exists(file.fasta), TRUE, FALSE)
# Retrieve the sequences and store them in list variable "seqs"
if(download){
  if (database == "ncbi_protein") {
    ACtrfA <- c("CAJ85685", "CAJ43307", "ADD63272", "AGH89267")
    #           RK2_TrfA2  pQKH54_trfA1 pAKD4_TrfA2 pDS1_trfA
    ACtrfA_ <- c("AJE23484", "APB02231", "ADF36658", "QED93016", "ABI60760", "CAZ90403", "CAG37865")
    #            "pAcX50c",  "pMCR_1511", "pEP5289", "_Ee_1",    "_Ne_p1",   "pTHI", "_Desps_large"
    ACtrfA. <- c("AEC19138", "WP_239990634", "CAB4139713", "DAW83606", "KAF0750528", "EEF25340", "WP_309917052.1", "AAR35551.1", "ACD94061.1", "QEU26305.1", "QEU27263.1") # w/o Pseudomonas aeruginosa strain 4782MK
    #ACCESSIONs <- c(ACtrfA, ACtrfA_)
    ACCESSIONs <- c(ACtrfA, ACtrfA_, ACtrfA.)
    
    seqs <- lapply(ACCESSIONs, function(x) rentrez::entrez_fetch(db="protein", id=x, rettype="fasta"))
    write(unlist(seqs), file=file.fasta)
  } else if (database == "uniprot") {
    ACCESSIONs <- c("P68104", "Q8U152", "P33166", "P13639", "P61877", "P80868") # Elongation factor
    #ACCESSIONs <- c("P01958", "P69905", "P69907", "P02062", "P68871", "P68873") # Hemoglobin subunit
    #ACCESSIONs <- c("P60174", "P00939", "P00942", "P0A858") # Triosephosphate isomerase
    
    # Create a function to retrieve several sequences from UniProt
    read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
    seqs <- lapply(ACCESSIONs, read.fasta.uniprot)
    # Write sequence(s) in FASTA formatted files
    write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))
  }
}

#' Read amino-acid sequences from a file in FASTA format.
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)

# Get sequence features: hydrophobicity, length, and annotations
Hydrophobicity <- Peptides::hydrophobicity(seqs, scale="KyteDoolittle")
Length <- getLength(seqs) # get the length of sequences
Annotation <- unlist(getAnnot(seqs)) # get sequence annotations

# Pattern Matching and Replacement
Accession <- gsub(pattern="^(UniRef[0-9]+_)*(sp\\|)?([^ .|]+).*", replacement="\\3", x=Annotation)
Accession <- gsub(pattern="^(UniRef[0-9]+_)*((sp|tr)\\|)?([^ .|]+).*", replacement="\\4", x=Annotation)

ProteinName <- Annotation
# "sp|P21074.3|A57_VACCC RecName: Full=Guanylate kinase homolog"
#ProteinName <- gsub(pattern="^([^ ]+) (RecName: .+)", replacement="\\2", x=ProteinName)
# "sp|P21074|A57_VACCC Guanylate kinase homolog OS=Vaccinia virus (strain Copenhagen) OX=10249 GN=A57R PE=3 SV=3"               
# "UniRef50_A0A4Y5MWZ9 Guanylate kinase-like domain-containing protein n=5 Tax=Orthopoxvirus TaxID=10242 RepID=A0A4Y5MWZ9_9POXV"
#ProteinName <- gsub(pattern="^([^ ]+) (.+) (OS|n)=.+", replacement="\\2", x=ProteinName)
# "AAM13634.1 CPXV195 protein [Cowpox virus]"
#ProteinName <- gsub(pattern="^([^ ]+) (.+) \\[(.+)\\]", replacement="\\2", x=ProteinName)
# one line
ProteinName <- gsub(pattern="^([^ ]+) (.+?) (\\[.+\\])$|^([^ ]+) (.+?) (OS|n)=.+|^([^ ]+) (RecName: .+)", replacement="\\2\\5\\8", x=ProteinName)
#ProteinName

OrganismName <- Annotation
# "AAM13634.1 CPXV195 protein [Cowpox virus]"
#OrganismName <- gsub(pattern=".+\\[(.+)\\]", replacement="\\1", x=OrganismName)
# "sp|P21074|A57_VACCC Guanylate kinase homolog OS=Vaccinia virus (strain Copenhagen) OX=10249 GN=A57R PE=3 SV=3"               
# "UniRef50_A0A4Y5MWZ9 Guanylate kinase-like domain-containing protein n=5 Tax=Orthopoxvirus TaxID=10242 RepID=A0A4Y5MWZ9_9POXV"
#OrganismName <- gsub(pattern=".+ (OS|Tax)=(.+) (OX|TaxID)=.+", replacement="\\2", x=OrganismName)
# "sp|P21074.3|A57_VACCC RecName: Full=Guanylate kinase homolog"
#OrganismName <- gsub(pattern="sp\\|[^|]+\\|([^ ]+) RecName: .*", replacement="\\1", x=OrganismName)
# one line
OrganismName <- gsub(pattern=".+\\[(.+)\\]|.+(OS|Tax)=(.+) (OX|TaxID)=.+|sp\\|[^|]+\\|([^ ]+) RecName: .*", replacement="\\1\\3\\5", x=OrganismName)
#OrganismName

# Creates data frame (table)
#Annotation <- substr(x=Annotation, start=1, stop=70)
mydata <- data.frame(Hydrophobicity, Length, Accession, ProteinName, OrganismName, Annotation) %>% arrange(desc(`Length`))
knitr::kable(x = mydata, caption = "Table 1. Sequence data.")

# Filter sequences based on length criteria
#hist(mydata$Length) # Histograms
summary(mydata$Length) # Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
length_min <- min(Length); length_min # Replace this value with your own criteria.
length_max <- max(Length); length_max # Replace this value with your own criteria.
TF <- length_min <= Length & Length <= length_max; summary(TF); seqs <- seqs[TF]
#TF <- grepl(pattern="Fragment|Isoform", x=getAnnot(seqs), ignore.case=TRUE); summary(TF); seqs <- seqs[!TF]
# Write sequence(s) in FASTA formatted files
file.fasta <- "myAA_filtered.fasta"
mynames <- getAnnot(seqs)
mynames <- getName(seqs)
#mynames <- gsub(pattern="\\..+", replacement="", x=getName(seqs)) # alignment and tree need to have the same names in PhyKIT
write.fasta(sequences=seqs, names=mynames, file.out=file.fasta, nbchar=max(getLength(seqs)))

#' # Aligning the Sequences
#' - Vignettes: [The Art of Multiple Sequence Alignment in R](https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf)
#library(DECIPHER)
myAAStringSet <- Biostrings::readAAStringSet(filepath=file.fasta)
myAlignAA <- DECIPHER::AlignSeqs(myAAStringSet)
#myAlignAA <- subseq(myAlignAA, start=73, end=162)
myAlignAA
#DECIPHER::BrowseSeqs(myAlignAA, threshold = 0.5) # ?ConsensusSequence

# write an XStringSet object to a file
file.align.untrimmed <- "myAlign.fasta"
Biostrings::writeXStringSet(x=myAlignAA, filepath=file.align.untrimmed)

#' ## Trimming multiple sequence alignments
#' - https://cran.r-project.org/package=microseq
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = file.align.untrimmed)
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0, gap.mid = 0)
print(nchar(msa.trimmed$Sequence))
file.align.trimmed <- "myAlignTrim.fasta"
microseq::writeFasta(fdta = msa.trimmed, out.file = file.align.trimmed, width = 80)

# read the FASTA-format alignment into R
file_align <- file.align.untrimmed
myAln <- seqinr::read.alignment(file=file_align, format="fasta", forceToLower=FALSE)
unlist(myAln$seq)

#' ## Sequence Logos
#' - https://cran.r-project.org/package=ggseqlogo
#' - https://omarwagih.github.io/ggseqlogo/
#require(ggplot2) #require(ggseqlogo) #?geom_logo
ggseqlogo(data=substr(x=toupper(myAln$seq), start=1, stop=40), seq_type='aa', method='bits') # method='prob'

#' ## Check Average Identity to Estimate Reliability of the Alignment
# squared root of pairwise distances from aligned sequences
mydist <- seqinr::dist.alignment(x=myAln, matrix="identity", gap=FALSE)
mean(mydist ^ 2); #summary(as.vector(mydist ^ 2))
#' - Phylogenetic Trees Made Easy: A How-To Manual (5th edition)
#' (p.60) *Codons: Pairwise amino acid identity* | 
#' The p-distance is 1–amino acid identity; thus 
#' if the average p-distance is <0.7 the alignment is acceptable; 
#' if ≥0.7 it is unreliable.
#' 
#' # Estimating Phylogenetic Trees
#' ## Distance based methods
#' - Vignettes: [Estimating phylogenetic trees with phangorn](https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html)
#' After constructing a distance matrix, we reconstruct a rooted tree with UPGMA and alternatively an unrooted tree using Neighbor Joining
#library(phangorn)
myphyDat <- read.phyDat(file=file_align, format="fasta", type="AA")
#names(myphyDat) <- gsub(pattern="^(UniRef[0-9]+_)*((sp|tr)\\|)?([^ .|]+).*", replacement="\\4", x=names(myphyDat))
if(UPGMA_NJ == "UPGMA") myfun <- function(x) upgma(dist.ml(x, model=mymodel, exclude=myexclude))
if(UPGMA_NJ == "NJ") myfun <- function(x) NJ(dist.ml(x, model=mymodel, exclude=myexclude))
mytree <- myfun(myphyDat); #summary(mytree$edge.length)

set.seed(123)
mytrees_bs <- bootstrap.phyDat(myphyDat, FUN=myfun, bs=100, multicore=TRUE)
#mytree <- plotBS(tree=mytree, BStrees=mytrees_bs) # version 2.11.1 # further parameters used by `plot.phylo` #plot=TRUE
mytree <- plotBS(tree=mytree, trees=mytrees_bs) # version 2.12.1
if (all(mytree$node.label <= 1)) { mytree$node.label <- mytree$node.label * 100 }
#' ## Substitution Saturation Analysis
d_patristic <- cophenetic(mytree)
d_uncorrected <- mydist ^ 2
nms <- rownames(as.matrix(d_uncorrected))
d_patristic <- as.dist(d_patristic[nms, nms])
summary(as.vector(d_patristic))
summary(as.vector(d_uncorrected))
mylim <- range(d_patristic, d_uncorrected)
mymax <- max(d_patristic, d_uncorrected)
plot(d_patristic, d_uncorrected, xlim=c(0,mymax), ylim=c(0,1), xlab="Patristic distance", ylab="Uncorrected distance")
abline(a = 0, b = 1, col = "blue") # x=y line
#abline(h = 1, col = "red") # y=1 line
#fit <- lm(d_uncorrected ~ d_patristic); fit; coef(fit)[2]
fit <- lm(d_uncorrected ~ d_patristic - 1) # linear regressions performed through the origin (i.e., the intercept is set to zero).
fit
#summary(fit)
#' 
#' ## Unrooted and Rooted Trees
# Outgroup or Midpoint rooting
outgroups <- c()
#outgroups <- mytree$tip.label[c(1,length(mytree$tip.label))]
#my.subtrees <- subtrees(mytree) #length(my.subtrees) #sapply(my.subtrees, function(x) length(x$tip.label)) #outgroups <- my.subtrees[[1]]$tip.label
#TF <- grepl(pattern="KGUA_|virus", x=mydata$Annotation, ignore.case=FALSE); summary(TF); mydata$Annotation[TF]; outgroups <- mydata$Accession[TF]
TF <- ifelse(length(outgroups) > 0, ape::is.monophyletic(phy=mytree, tips=outgroups), FALSE )
tree.main <- ifelse(TF, "Outgroup rooted ", "Midpoint rooted ")
tree.main <- ifelse(UPGMA_NJ == "NJ", paste0(tree.main,UPGMA_NJ), UPGMA_NJ)
tree.main
#length(mytree$node.label); summary(mytree$node.label); mytree$node.label
if(TF) {
  mytree <- ape::root(phy=mytree, outgroup=outgroups, resolve.root=TRUE)
} else {
  if(UPGMA_NJ == "NJ"){ 
    mytree <- phangorn::midpoint(mytree)
    #mytree <- phytools::midpoint.root(mytree)
  }
}
#length(mytree$node.label); summary(mytree$node.label); mytree$node.label
mytree <- ladderize(mytree, right=TRUE)

#' ## write tree and data table
# write.tree / read.tree
write.tree(phy = mytree, file = "myTree.tre")
mytree <- read.tree(file = "myTree.tre")
mytree$node.label <- as.numeric(mytree$node.label)

# data table sorted by tree $tip.label
mydata <- mydata[match(rev(mytree$tip.label), rownames(mydata)),]
write_tsv(x=mydata, file="myTable.tsv")

x <- mytree$tip.label[1]; mydata[rownames(mydata) %in% x,c("Annotation")]
mytree$tip.label <- sapply(mytree$tip.label, function(x) mydata[rownames(mydata) %in% x,c("Annotation")] )

pdf("myTree.pdf", pointsize=10, width=15, height=9)
par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1.5, 0.5, 1, 0.5), cex=mycex) # c(bottom, left, top, right)
#plot.phylo(x=mytree, show.node.label=TRUE, main=paste0(tree.main," tree"), root.edge=TRUE, underscore=TRUE); ape::add.scale.bar(); axisPhylo()
plot.phylo(x=mytree, show.node.label=TRUE, root.edge=TRUE, underscore=TRUE); ape::add.scale.bar(); #axisPhylo()
dev.off()

sessionInfo()
Sys.time()
