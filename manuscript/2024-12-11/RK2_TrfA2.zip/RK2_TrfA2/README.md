Haruo Suzuki  
Last Update: 2025-05-31

# RK2_TrfA2 Project
Project started 2023-12-25.

This README file briefly explains the code, scripts, and input/output files used to generate the figures and tables in both the main text and the supplementary materials. 

```
cd ~/RK2_TrfA2/

cd ~/RK2_TrfA2/my_tblastn_nt_CAJ85685_TrfA2/R_tblastn/
ln -s ../my_join_taxonkit_blastdbcmd.txt
ln -s ../tblastn-nt-CAJ85685.fasta.txt
# script: Table_blast_blastdbcmd_taxonkit.R
# output: Table_tblastn-nt-CAJ85685.fasta.txt.tsv # Supplementary Table S1 # S1_tblastn-nt

cd ~/RK2_TrfA2/my_lsbsr/11198752/
# script: Table_lsbsr_g_diff_TrfA1_vs_TrfA2_seqkit.R
# input: lsbsr_g_bsr_matrix.txt
# output: Table_lsbsr_g_diff_TrfA1_vs_TrfA2_seqkit.tsv

cd ~/RK2_TrfA2/my_lsbsr/11198753/
# script: Table_lsbsr_g_BN000925_RK2.R
# input: lsbsr_g_bsr_matrix.txt
# input: BN000925.faa
# output: Table_lsbsr_g_BN000925_RK2_BSR.tsv
# output: Table_lsbsr_g_BN000925_RK2_number_genomes.tsv # Supplementary Table S2 # S2_lsbsr_number_genomes
# Compile Report: Table_lsbsr_g_BN000925_RK2.html # mv download.png R.ggscatterhist.nBSRgt0.meanBSR.png # Figure_1.png

# script: Table_lsbsr_seqkit.R
# input: Table_lsbsr_g_BN000925_RK2_BSR.tsv
# input: my.seqkit_fx2tab_-agHln.fna.txt
# output: Table_lsbsr_seqkit.tsv

cd ~/RK2_TrfA2/my_lsbsr/
# script: Table_lsbsr_join.R
# input: 11198752/Table_lsbsr_g_diff_TrfA1_vs_TrfA2_seqkit.tsv
# input: 11198753/Table_lsbsr_seqkit.tsv
# output: Table_lsbsr_join.tsv # Supplementary Table S3 # S3_lsbsr_seqkit

cd ~/RK2_TrfA2/my_blastp_nr_CAJ85685_TrfA2/R_blastp/
ln -s ../my_join_taxonkit_blastdbcmd.txt
ln -s ../blastp-nr-CAJ85685.fasta.txt
# script: Table_blast_blastdbcmd_taxonkit.R
# input: my_join_taxonkit_blastdbcmd.txt
# input: blastp-nr-CAJ85685.fasta.txt
# output: Table_blastp-nr-CAJ85685.fasta.txt.tsv # Supplementary Table S4 # S4_blastp-nr

cd ~/RK2_TrfA2/my_blastp_nr_CAJ85685_TrfA2/
awk -F"\t" '$4 ~ /^[0-9]+$/ {print $4}' my_join_taxonkit_blastdbcmd.txt > my_sequence_length_only.txt
# script: R_sequence_length/my_sequence_length_only.R
# input: my_sequence_length_only.txt
# Compile Report: my_sequence_length.html # mv download.png geom_histogram_binwidth_5.png # Figure_2.png

cd ~/RK2_TrfA2/my_tree_aa/n_21/
# script: my_tree_aa.R
# output: myTree.pdf # Figure_3.pdf

cd ~/RK2_TrfA2/my_tree_aa/n_23/
# script: my_tree_aa.R
# output: myAlign.fasta
cd ~/RK2_TrfA2/my_tree_aa/n_23/my_iqtree_myAlign/
alignment=myAlign.fasta
ln -s ../${alignment}
(bash run_iqtree.sh ${alignment} &) >& log.iqtree.$(date +%F).txt
cd ~/RK2_TrfA2/my_tree_aa/n_23/my_iqtree_myAlign/my_R/
# script: my_ggtree_labeled.R
# input: "../myAlign_iqtree_rev.treefile"
# input: "../../myAA.fasta"
# output: "my_ggtree_labeled.pdf" # Supplementary Figure S1

# script: my_saturation.R
# input: "../myAlign.fasta"
# input: "../myAlign_iqtree_rev.treefile"
# Compile Report: my_saturation.html # mv download.png my_saturation.png # Supplementary Figure S2
```

