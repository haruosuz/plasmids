Haruo Suzuki  
Last Update: 2024-12-11

# RK2_TrfA2 Project
Project started 2023-12-25.

This README file briefly explains the code and scripts, as well as the input and output files, used to create supplementary tables and figures in the manuscript.

```
cd ~
cd RK2_TrfA2/

cd ~/RK2_TrfA2/my_tblastn_nt_CAJ85685_TrfA2/R_tblastn/
ln -s ../my_join_taxonkit_blastdbcmd.txt
ln -s ../tblastn-nt-CAJ85685.fasta.txt
# script: Table_blast_blastdbcmd_taxonkit.R
# output: Table_tblastn-nt-CAJ85685.fasta.txt.tsv
# Supplementary Table S1 # S1_tblastn-nt

cd ~/RK2_TrfA2/my_tblastn_nt_CAJ85685_TrfA2/my_lsbsr/R_lsbsr/
ln -s ../lsbsr_g_bsr_matrix.txt
# script: Table_lsbsr_g_BN000925_RK2.R
# input: lsbsr_g_bsr_matrix.txt
# input: BN000925.faa
# output: R.lsbsr_g_bsr_matrix.tsv
# output: Table_lsbsr_g_BN000925_RK2_number_genomes.tsv
# Supplementary Table S2 # S2_lsbsr_number_genomes

cd ~/RK2_TrfA2/my_tblastn_nt_CAJ85685_TrfA2/my_lsbsr/R_lsbsr/
ln -s ../../my.seqkit_fx2tab_-agHln.fna.txt
# script: Table_lsbsr_seqkit.R
# input: R.lsbsr_g_bsr_matrix.tsv
# input: my.seqkit_fx2tab_-agHln.fna.txt
# output: Table_lsbsr_seqkit.tsv
# Supplementary Table S3 # S3_lsbsr_seqkit
# Compile Report: Table_lsbsr_g_BN000925_RK2.html # ln -s download.png R.ggscatterhist.sum_BSR.nBSRgt0.png # Figure_1.png

cd ~/RK2_TrfA2/my_COMPASS/
# script: my_plasmids_compass.R
# input: plasmids.txt
# input: COMPASS.tsv
# output: R.plasmids_compass.tsv
cat R.plasmids_compass.tsv | head -n 1 > R.plasmids_compass.tsv.TrfA2.tsv
ln -s ../my_tblastn_nt_CAJ85685_TrfA2/my_join_taxonkit_blastdbcmd.txt
cat my_join_taxonkit_blastdbcmd.txt | wc -l # 1675
cat R.plasmids_compass.tsv | grep -f <(cat my_join_taxonkit_blastdbcmd.txt | cut -f3 | sed 's/\.[0-9]*//g') | wc -l # 165
cat R.plasmids_compass.tsv | grep -f <(cat my_join_taxonkit_blastdbcmd.txt | cut -f3 | sed 's/\.[0-9]*//g') >> R.plasmids_compass.tsv.TrfA2.tsv
# Supplementary Table S4 # S4_COMPASS

cd ~/RK2_TrfA2/my_blastp_nr_CAJ85685_TrfA2/R_blastp/
ln -s ../my_join_taxonkit_blastdbcmd.txt
ln -s ../blastp-nr-CAJ85685.fasta.txt
# script: Table_blast_blastdbcmd_taxonkit.R
# input: my_join_taxonkit_blastdbcmd.txt
# input: blastp-nr-CAJ85685.fasta.txt
# output: Table_blastp-nr-CAJ85685.fasta.txt.tsv
# Supplementary Table S5 # S5_blastp-nr

cd ~/RK2_TrfA2/my_blastp_nr_CAJ85685_TrfA2/R_sequence_length/
ln -s ../my_sequence_length.txt
# script: my_sequence_length.R
# input: my_sequence_length.txt
# Compile Report: my_sequence_length.html # ln -s download.png geom_histogram_binwidth_5.png # Figure_2.png

cd ~/RK2_TrfA2/my_tree_aa/
# script: my_tree_aa.R
# output: myTree.pdf # Figure_3.pdf
# Compile Report: my_tree_aa.html # ln -s download.png R_d_patristic_d_uncorrected.png # Figure_4.png
```



