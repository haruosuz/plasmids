#!/bin/sh
#PBS -l nodes=1:ppn=32,mem=64gb,walltime=72:00:00
#PBS -N torque.sh
#set -e
#set -u
#set -o pipefail
set -euo pipefail

cd ${PBS_O_WORKDIR}

echo; echo "[$(date)] $0 job has been started."

# fasta
DIRECTORY=$PWD/data/fna
find $DIRECTORY -name "*.fna.fasta" | xargs -I{} rm {}
find $DIRECTORY -name "*.fna" | xargs -I{} ln -s {} {}.fasta

#conda info --envs
source /home/haruo/miniforge3/etc/profile.d/conda.sh
conda activate base
echo; echo "[$(date)] https://github.com/jasonsahl/LS-BSR"
conda activate ls_bsr

echo; echo "[$(date)] Run the gene screen method with tblastn:"
time bash ./scripts/run_lsbsr_g.sh $DIRECTORY
#Rscript --vanilla ./scripts/my_lsbsr_g.R

#echo; echo "[$(date)] Run the de novo gene prediction method:"
#time bash ./scripts/run_lsbsr_c.sh $DIRECTORY
#Rscript --vanilla ./scripts/my_lsbsr_c.R

echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

qsub torque.sh
qstat -u $(whoami)

#__COMMENT_OUT__
