#!/usr/bin/bash
set -e
#set -u
set -o pipefail
#set -euo pipefail
#/home/haruo/miniconda3/etc/conda/deactivate.d/deactivate-gxx_linux-64.sh: line 65: CONDA_BACKUP_CXX: unbound variable

# start
echo; echo "[$(date)] $0 job has been started."

# [cp-support:25836] 
source /home/haruo/miniconda3/etc/profile.d/conda.sh
conda activate base
# To activate this environment, use
conda activate ls_bsr

python /home/haruo/tools/my_lsbsr/LS-BSR/ls_bsr.py --version

# Variables and Command Arguments


# done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

echo; echo "# Post-matrix scripts"
PREFIX=lsbsr_c_usearch

# Preparing input files for "# 10. invert_select_group.py" and "# 1. compare_BSR.py" 
#cat ${PREFIX}_names.txt | sort | head -n 2 > group1.txt
#cat ${PREFIX}_names.txt | sort | tail -n 2 > group2.txt
echo "BDSN01000001-BDSN01000094.fna" > group1.txt
echo; echo "# 10. invert_select_group.py"
invert_select_group.py group1.txt ${PREFIX}_names.txt > group2.txt

echo; echo "# 1. compare_BSR.py"
compare_BSR.py -1 group1.txt -2 group2.txt -f ${PREFIX}_consensus.fasta -b ${PREFIX}_bsr_matrix.txt
ls -ltr group*
grep -c "^>" group*_unique_seqs.fasta

echo; echo "# 2. filter_BSR_variome.py"
filter_BSR_variome.py -b ${PREFIX}_bsr_matrix.txt
head -n 2 variome_BSR_matrix

echo; echo "# 3. filter_column_BSR.py"
cat ${PREFIX}_names.txt | sort | tail -n 2 > to_remove.txt
filter_column_BSR.py -b ${PREFIX}_bsr_matrix.txt -p pruned -g to_remove.txt
head -n 2 pruned_genomes.matrix

echo; echo "# 4. isolate_uniques_BSR.py"
isolate_uniques_BSR.py -b ${PREFIX}_bsr_matrix.txt -t 0.4
head -n 2 uniques_BSR_matrix

echo; echo "# 5. pan_genome_stats.py"
pan_genome_stats.py -b ${PREFIX}_bsr_matrix.txt -u 0.8 -l 0.4
head -n 2 core_gene_ids.txt unique_gene_ids.txt frequency_data.txt


echo; echo "# 11. select_seqs_by_IDs.py"
select_seqs_by_IDs.py -i ${PREFIX}_consensus.fasta -d core_gene_ids.txt -o core_gene.fasta
select_seqs_by_IDs.py -i ${PREFIX}_consensus.fasta -d unique_gene_ids.txt -o unique_gene.fasta
grep -c "^>" core_gene.fasta unique_gene.fasta

echo; echo "# 6. BSR_to_PANGP.py"
BSR_to_PANGP.py -b ${PREFIX}_bsr_matrix.txt -l 0.8
head -n 6 panGP_matrix.txt

echo; echo "# 7. BSR_to_gene_accumulation_scatter.py"
BSR_to_gene_accumulation_scatter.py -b ${PREFIX}_bsr_matrix.txt -u 0.8 -l 0.4 -n 10 -t all -p out7
head -n 2 *_replicates.txt

echo; echo "# 8. quantify_BSR_uniques.py"
echo; echo "# 9. reorder_BSR_matrix_by_tree.py"

echo; echo "# 12. slice_ref_genome.py"
# non-overlapping windows
#slice_ref_genome.py -r data/fna/NC_001735.fasta -f 1000 -s 1000
for file in `ls data/fna/*.fasta`; do slice_ref_genome.py -r $file -f 1000 -s 1000; done
grep -c "^>" *_seqs_shredded.txt

echo; echo "# 13. transfer_annotation.py"

echo; echo "# 14. extract_locus_tags.py"
find data/gbk -name "*.gbk" | xargs -I{} extract_locus_tags.py {}

echo; echo "# 15. extract_core_genome.py"
extract_core_genome.py -d data/fna -g ${PREFIX}_consensus.fasta


echo; echo "# 16. annotate_matrix_by_locus_tags.py"
annotate_matrix_by_locus_tags.py -b ${PREFIX}_bsr_matrix.txt -c ${PREFIX}_consensus.fasta -l ./NC_001735.fasta -t 80 -p out16
(head -n 2; tail -n 2) < bsr_matrix_annotated.txt
grep "^>" *.consensus_annotated.fasta | head


https://github.com/haruosuz/mgsa/tree/master/tools/lsbsr

https://github.com/jasonsahl/LS-BSR


https://github.com/jasonsahl/LS-BSR/blob/master/manual.md

mmseqs2 [optional]
If you invoke with "-c mmseqs", it runs the "easy-cluster" method; if the "-c mmseqs-lin" is invoked, it runs the "easy-linclust" method.

Currently, VSEARCH does not work with protein sequences and you will see a warning if you try to combine VSEARCH with BLASTP or DIAMOND.

https://github.com/jasonsahl/LS-BSR/blob/master/manual.md
-p PROCESSORS: number of processors to use, defaults to 2.
-g GENES: if you have a list of genes to screen, supply a nucleotide fasta file (.fasta) or a peptide file (.pep). Each gene sequence must be in frame, or questionable results will be obtained (only true for TBLASTN). If this flag is not invoked, then the de novo gene prediction method is invoked
-c CLUSTER_METHOD: determines which clustering method to choose. You can choose from “mmseqs”, "mmseqs-lin", “vsearch”, or “cd-hit”. These must be in your path as “mmseqs”, “vsearch”, “cd-hit-est”, or “cd-hit” to use.

From: Jason Sahl <jasonsahl@gmail.com>
Subject: Re: LS-BSR printed OSError: [Errno 18] Invalid cross-device link
Yes, you would run “-c” or “-g”, but never both.


ps aux | grep "haruo" | grep "LS-BSR\|usearch\|tblastn" | awk '{print $2}' > mylist; for i in `cat mylist`; do kill $i; done

Let's run the driver script in the project's main directory with:

#(time bash ./run_lsbsr.sh &) >& log.lsbsr.post.$(date +%F).txt
(time bash ./run_lsbsr.sh &) >& log.lsbsr.$(date +%F).txt

#__COMMENT_OUT__
