#!/usr/bin/bash
set -e
#set -u
set -o pipefail
#set -euo pipefail
#/home/haruo/miniconda3/etc/conda/deactivate.d/deactivate-gxx_linux-64.sh: line 65: CONDA_BACKUP_CXX: unbound variable

# start
echo; echo "[$(date)] $0 job has been started."

# [cp-support:25836] 
source /home/haruo/miniconda3/etc/profile.d/conda.sh
conda activate base
# To activate this environment, use
conda activate ls_bsr

python /home/haruo/tools/my_lsbsr/LS-BSR/ls_bsr.py --version

# Variables and Command Arguments
DIRECTORY=$1

CLUSTER_METHOD=mmseqs
CLUSTER_METHOD=mmseqs-lin # This mode is recommended for huge datasets. # https://github.com/soedinglab/mmseqs2
PREFIX=lsbsr_c_${CLUSTER_METHOD}
PREFIX=lsbsr_c
python /home/haruo/tools/my_lsbsr/LS-BSR/ls_bsr.py -p $(getconf _NPROCESSORS_ONLN) -d $DIRECTORY -x $PREFIX -c ${CLUSTER_METHOD}

# done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

(time bash ./run_lsbsr_c.sh &) >& log.lsbsr_c.$(date +%F).txt

#__COMMENT_OUT__
