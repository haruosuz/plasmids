rm(list = ls())
#library(tidyverse)
library(ape)

# the de novo gene prediction method
filename <- "lsbsr_c_bsr_matrix.txt"
d <- read.delim(file=filename, quote="", row.names=1, na.strings="-", check.names=FALSE)
dim(d)
#pdf(file = "R.lsbsr_c_bsr_matrix.pdf")
hc <- hclust(dist(t(d), method="euclidean"), method="average"); #plot(hc)
write.tree(phy=ladderize(phy=as.phylo(hc), right=TRUE), file = "R.lsbsr_c_bsr_matrix.hclust.euclidean.tre")
#heatmap(t(as.matrix(d)), margins=c(0.5, 8), labCol=NA, col=rev(gray.colors(12)), scale="none", Rowv=as.dendrogram(hc), main="average_euclidean")
hc <- hclust(as.dist(1-cor(d, method="pearson")), method="average"); #plot(hc)
write.tree(phy=ladderize(phy=as.phylo(hc), right=TRUE), file = "R.lsbsr_c_bsr_matrix.hclust.correlation.tre")
#heatmap(t(as.matrix(d)), margins=c(0.5, 8), labCol=NA, col=rev(gray.colors(12)), scale="none", Rowv=as.dendrogram(hc), main="average_correlation")
#dev.off()

#getwd()
#list.files()
sessionInfo()
Sys.time()
