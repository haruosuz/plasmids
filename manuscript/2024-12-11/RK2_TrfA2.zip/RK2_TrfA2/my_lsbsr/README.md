Haruo Suzuki  
Last Update: 2025-03-20

----------

# TTCK LS-BSR project
Project started 2025-03-20

I have created shell and R scripts to perform analyses in
[LS-BSR (Large Scale Blast Score Ratio)](https://github.com/jasonsahl/LS-BSR)

- [data](#data)
- [scripts](#scripts)
- [analysis](#analysis)
- [seqkit](#seqkit)
- [R packages](#r-packages)
- [references](#references)

## project directories
```
my_test_lsbsr/
./README.md: project documentation 
./data/: contains data files
./scripts/: contains R and Shell scripts
./analysis/: contains results of data analyses
```

## data

Test data (complete sequences of 6 plasmids) are as follows:
```
data/fna/AB231906.fna
data/fna/AM157767.fna
data/fna/AM261282.fna
data/fna/BN000925.fna
data/fna/GQ983559.fna
data/fna/U67194.fna
```
FASTA files in the *./data/fna/* directory should be replaced with the FASTA file of the DNA sequences of interest.

## scripts

First, run it with test data to check reproducibility.
Next, apply it to your own data.

*scripts/pbs.sh* carries out the entire steps.
Run the script using:
```
# Submit a job to the queue with the `qsub` command.
qsub scripts/torque.sh

# Check the status of jobs with the `qstat` command.
qstat -u $(whoami)

# Check files in your current/working directory
ls -lrt

# Look at the standard output (*.o) and standard error (*.e) files.
tail torque.sh.*
```

*scripts/pbs.sh*
```
echo; echo "[$(date)] Run the gene screen method with tblastn:"
time bash ./scripts/run_lsbsr_g.sh $DIRECTORY
Rscript --vanilla ./scripts/my_lsbsr_g.R

#echo; echo "[$(date)] Run the de novo gene prediction method:"
#time bash ./scripts/run_lsbsr_c.sh $DIRECTORY
#Rscript --vanilla ./scripts/my_lsbsr_c.R
```
Remove the hash `#` as needed (to run the de novo gene prediction method).

*scripts/run_lsbsr_g.sh*
```
ACCESSION=BN000925 # RK2 IncP-1alpha
#ACCESSION=U67194 # R751 IncP-1beta1
#ACCESSION=AY365053 # Ralstonia eutropha JMP134 plasmid pJP4
#ACCESSION=GU479466 # Neisseria gonorrhoeae strain 5289 plasmid pEP5289
#ACCESSION=KC241982 # Canine circovirus isolate UCD1-1698
```
Edit `ACCESSION` as needed (to change query protein sequences used for TBLASTN search).

*scripts/my_lsbsr_g.R* calculates two summary statistics from the BSR values: (i) the sum of BSR values, abbreviated as 'sum_BSR', and (ii) the number of genes with BSR values greater than 0, abbreviated as 'nBSRgt0' (indicating the number of genes detected in the genome).
```
sum_BSR <- apply(d, 2, sum) # Sum of BSR values
nBSRgt0 <- apply(d > 0, 2, sum) # Number of genes with BSR values greater than 0
```

## analysis

Running the script generates the following output files:
```
# standard output and standard error
pbs.sh.e*
pbs.sh.o*

# output of the gene screen method with tblastn
lsbsr_g_bsr_matrix.txt
lsbsr_g_names.txt
lsbsr_g_run_parameters.txt
R.lsbsr_g_bsr_matrix.tsv

# output of the de novo gene prediction method
lsbsr_c_bsr_matrix.txt
lsbsr_c_consensus.fasta
lsbsr_c_consensus.pep
lsbsr_c_names.txt
lsbsr_c_run_parameters.txt
R.lsbsr_c_bsr_matrix.hclust.correlation.tre
R.lsbsr_c_bsr_matrix.hclust.euclidean.tre
```

https://github.com/jasonsahl/LS-BSR/blob/master/manual.md
$prefix_bsr_matrix.txt: This is the 2x2 matrix of the BSR value for each CDS in each genome queried

To create a BSR matrix with annotations, type (edit `ACCESSION` as necessary):
```
ACCESSION=AB231906 # IncP-1beta2 pA1
GENES=$PWD/data/faa/$ACCESSION.faa
grep "^>" $GENES | perl -pe 's/(>(\S+) (.+))/$2\t$1/;' | sort > my.annotation.tsv
# https://github.com/haruosuz/introBI/blob/master/2023-04/README.md#join
sort -c -k1,1 lsbsr_g_bsr_matrix.txt # verifies is already sorted
head -n 1 lsbsr_g_bsr_matrix.txt > my.lsbsr_g_bsr_matrix.annotation.tsv
join -1 1 -2 1 -t "$(printf '\011')" lsbsr_g_bsr_matrix.txt my.annotation.tsv >> my.lsbsr_g_bsr_matrix.annotation.tsv

cat my.lsbsr_g_bsr_matrix.annotation.tsv | grep -i "trfA\|traI"
```

### seqkit
Run SeqKit (https://bioinf.shenwei.me/seqkit/) to compute sequence length (bp) and GC content (%) using:
```
find ./data/fna -name "*.fna" | sort | xargs seqkit fx2tab -agHln > my.seqkit_fx2tab_-agHln.fna.txt
```

Sort by sequence length:
```
tail -n +2 my.seqkit_fx2tab_-agHln.fna.txt | awk -F "\t" '{ print $2,$3,$1 }' | sort -k1,1n
```

Join LS-BSR and SeqKit resuls.
```
join -t "$(printf '\011')" -1 1 -2 1 <(tail -n +2 R.lsbsr_g_bsr_matrix.tsv | sort) <(tail -n +2 my.seqkit_fx2tab_-agHln.fna.txt | perl -pe 's/((\S+)\.[0-9]+ (.+))/$2\t$3/;' | sort) > my.join.lsbsr.seqkit.txt
cat my.join.lsbsr.seqkit.txt | sort -k2,2nr
cat my.join.lsbsr.seqkit.txt | sort -k3,3nr | grep -n "partial"
```

### R packages

You need to install the R packages.

Type the following commands:
```
module avail
# R/4.0.3(default)
module load R/4.0.3
```
https://biaswiki.nibb.ac.jp/menu/images/4/49/2_biodb_2022.pdf
module load

To start R, type:
```
R
```

Type in the R console:
```
# To install the R packages
> options(repos="https://cran.ism.ac.jp/")
> install.packages("ape")

# To quit R
> q()
Save workspace image? [y/n/c]: n
```

## references
- https://github.com/haruosuz/mgsa/tree/master/tools/lsbsr
- 
- https://github.com/jasonsahl/LS-BSR
- https://github.com/jasonsahl/LS-BSR/blob/master/manual.md

----------
