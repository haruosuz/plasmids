Sys.time()
# rm(list = ls())
library(tidyverse)
#' - [10 Tibbles | R for Data Science](https://r4ds.had.co.nz/tibbles.html)
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns

filename <- "11198752/Table_lsbsr_g_diff_TrfA1_vs_TrfA2_seqkit.tsv"
d <- read_tsv(file = filename); dim(d); head(d); tail(d)
d.sub <- d[,1:3]

filename <- "11198753/Table_lsbsr_seqkit.tsv"
d <- read_tsv(file = filename); dim(d); head(d); tail(d)
d.all <- d

d <- inner_join(x=d.sub, y=d.all, by=c("accession" = "accession")); dim(d); head(d,1); tail(d,1)
d <- d[order(d$nBSRgt0, d$meanBSR, decreasing=TRUE),]
write_tsv(d, paste0("Table_lsbsr_join.tsv"))

summary(d$`BN000925|complement(17379..17669)` > 0)
summary(d$`U67194|complement(16084..16449)` > 0)

TF <- grepl(pattern="AY540995", x=d$accession); d[TF,] # pEST4011
TF <- grepl(pattern="JX847411", x=d$accession); d[TF,] # pIJB1
TF <- grepl(pattern="GQ983559", x=d$accession); d[TF,] # pAKD4

#' - https://pmc.ncbi.nlm.nih.gov/articles/PMC2819548/
#' Interestingly, since all three IncP-1δ plasmids are missing the 5′end of trfA, which encodes the start codon for and the N-terminal region (350 bp) of TrfA1, TrfA2 is the only replication initiation protein encoded by these plasmids.
#' 