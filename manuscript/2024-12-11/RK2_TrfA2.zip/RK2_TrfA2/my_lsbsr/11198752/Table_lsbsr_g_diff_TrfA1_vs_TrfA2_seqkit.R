Sys.time()
# rm(list = ls())
library(tidyverse)
#' - [10 Tibbles | R for Data Science](https://r4ds.had.co.nz/tibbles.html)
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns

#' - https://github.com/jasonsahl/LS-BSR/blob/master/manual.md
#' the gene screen method with TBLASTN
#' $prefix_bsr_matrix.txt: This is the 2x2 matrix of the BSR value for each gene in each genome queried
filename <- "lsbsr_g_bsr_matrix.txt"
d <- read.delim(file=filename, quote="", row.names=1, na.strings="-", check.names=FALSE)
dim(d)
#accession <- gsub(pattern="^([^\\.]+)(\\.[0-9])*\\.fna", replacement="\\1", x=colnames(d))
accession <- sub("\\.fna$", "", colnames(d))
colnames(d) <- accession
x <- t(d)[,1] # BSR values for 1st gene in genome
y <- t(d)[,2] # BSR values for 2nd gene in genome
plot(x, y, xlab="x axis", ylab="y axis"); cor(x, y, method="spearman")
d.f <- data.frame(accession, t(d), check.names=FALSE)
d.f <- d.f[order(d.f$`BN000925|complement(17379..17669)`, d.f$`U67194|complement(16084..16449)`, decreasing=TRUE),]
d.l <- d.f

filename <- "my.seqkit_fx2tab_-agHln.fna.txt"
d <- read_tsv(file = filename); dim(d); head(d); tail(d)
#d$accession <- sapply(strsplit(d$`#name`, " "), function(x) sub("\\.\\d+$", "", x[1]))
d$accession <- sapply(strsplit(d$`#name`, " "), function(x) x[1])
d$sequence_title <- sapply(strsplit(d$`#name`, " "), function(x) paste(x[-1], collapse = " "))
d <- d[, !colnames(d) %in% "#name"]
d.s <- d

d <- inner_join(x=d.l, y=d.s, by=c("accession" = "accession")); dim(d); head(d,1); tail(d,1)
write_tsv(d, paste0("Table_lsbsr_g_diff_TrfA1_vs_TrfA2_seqkit.tsv"))

summary(d$`BN000925|complement(17379..17669)` > 0)
summary(d$`U67194|complement(16084..16449)` > 0)

