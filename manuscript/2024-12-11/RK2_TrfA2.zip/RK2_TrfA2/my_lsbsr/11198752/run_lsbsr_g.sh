#!/usr/bin/bash
set -e
#set -u
set -o pipefail
#set -euo pipefail
#/home/haruo/miniconda3/etc/conda/deactivate.d/deactivate-gxx_linux-64.sh: line 65: CONDA_BACKUP_CXX: unbound variable

# start
echo; echo "[$(date)] $0 job has been started."

# [cp-support:25836] 
#source /home/haruo/miniconda3/etc/profile.d/conda.sh
#conda activate base
# To activate this environment, use
#conda activate ls_bsr

python /home/haruo/tools/my_lsbsr/LS-BSR/ls_bsr.py --version

# Variables and Command Arguments
DIRECTORY=$1
ACCESSION=diff_TrfA1_vs_TrfA2 # TrfA1_unique_N-term
#ACCESSION=BN000925 # RK2 IncP-1alpha
#ACCESSION=U67194 # R751 IncP-1beta1
#ACCESSION=AY365053 # Ralstonia eutropha JMP134 plasmid pJP4
#ACCESSION=GU479466 # Neisseria gonorrhoeae strain 5289 plasmid pEP5289
#ACCESSION=KC241982 # Canine circovirus isolate UCD1-1698

if [ ! -e "data/faa/$ACCESSION.faa" ]; then mkdir -p data/faa; wget -O "data/faa/$ACCESSION.faa" "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=$ACCESSION&rettype=fasta_cds_aa&retmode=text"; fi

GENES=$PWD/data/faa/$ACCESSION.faa
if [ ! -e $GENES.pep ]; then ln -s $GENES $GENES.pep; fi
#grep "^>" $GENES.pep | perl -pe 's/(>(\S+) (.+))/$2\t$1/;' | sort > $GENES.pep-header
PREFIX=lsbsr_g
#python /home/haruo/tools/my_lsbsr/LS-BSR/ls_bsr.py -p $(getconf _NPROCESSORS_ONLN) -d $DIRECTORY -x $PREFIX -g $GENES.pep -b tblastn
ls_bsr_py=/home/haruo/tools/my_lsbsr/LS-BSR/ls_bsr.py
#python $ls_bsr_py -p $(getconf _NPROCESSORS_ONLN) -d $DIRECTORY -x $PREFIX -g $GENES.pep -b tblastn
python $ls_bsr_py -p $(getconf _NPROCESSORS_ONLN) -d $DIRECTORY -x $PREFIX -g $GENES.pep -b tblastn -k T
# -k KEEP: keep or remove temp files, choose from T or F, defaults to False (F), choose from T or F
# https://github.com/jasonsahl/LS-BSR/blob/master/manual.md

# done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

(time bash ./run_lsbsr_g.sh &) >& log.lsbsr_g.$(date +%F).txt

#__COMMENT_OUT__
