rm(list = ls())
#' - https://github.com/jasonsahl/LS-BSR/blob/master/manual.md
#' the gene screen method with TBLASTN
#' $prefix_bsr_matrix.txt: This is the 2x2 matrix of the BSR value for each gene in each genome queried
filename <- "lsbsr_g_bsr_matrix.txt"
d <- read.delim(file=filename, quote="", row.names=1, na.strings="-", check.names=FALSE)
dim(d)
accession <- gsub(pattern="^([^\\.]+)(\\.[0-9])*\\.fna", replacement="\\1", x=colnames(d))
colnames(d) <- accession
#x <- t(d)[,1] # BSR values for 1st gene in genome
#y <- t(d)[,2] # BSR values for 2nd gene in genome
#plot(x, y, xlab="x axis", ylab="y axis"); cor(x, y, method="spearman")
#heatmap(t(as.matrix(d)), scale="none", margins=c(6,1), cexRow=1, cexCol=1/3, col=rev(gray.colors(12)), main="Heatmap")
#d <- ifelse(d > 0, 1, 0) # Convert the BSR value to binary code (1/0) indicating gene presence/absence
sum_BSR <- apply(d, 2, sum) # Sum of BSR values
nBSRgt0 <- apply(d > 0, 2, sum) # Number of genes with BSR values greater than 0
#plot(sum_BSR, nBSRgt0); cor(sum_BSR, nBSRgt0, method="spearman")
d.f <- data.frame(accession, sum_BSR, nBSRgt0)
d.f <- d.f[order(d.f$sum_BSR, decreasing=TRUE),]
# Exporting Data
write.table(d.f, file="R.lsbsr_g_bsr_matrix.tsv", sep="\t", quote=FALSE, row.names=FALSE)

#getwd()
#list.files()
sessionInfo()
Sys.time()
