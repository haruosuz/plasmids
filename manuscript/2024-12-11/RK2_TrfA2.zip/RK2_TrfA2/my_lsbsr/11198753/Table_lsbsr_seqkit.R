Sys.time()
# rm(list = ls())
library(tidyverse)
#' - [10 Tibbles | R for Data Science](https://r4ds.had.co.nz/tibbles.html)
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns

filename <- "Table_lsbsr_g_BN000925_RK2_BSR.tsv"
d <- read_tsv(file = filename); dim(d); head(d); tail(d)
d.l <- d

filename <- "my.seqkit_fx2tab_-agHln.fna.txt"
d <- read_tsv(file = filename); dim(d); head(d); tail(d)
#d$accession <- sapply(strsplit(d$`#name`, " "), function(x) sub("\\.\\d+$", "", x[1]))
d$accession <- sapply(strsplit(d$`#name`, " "), function(x) x[1])
d$sequence_title <- sapply(strsplit(d$`#name`, " "), function(x) paste(x[-1], collapse = " "))
d <- d[, !colnames(d) %in% "#name"]
d.s <- d

d <- inner_join(x=d.l, y=d.s, by=c("accession" = "accession")); dim(d); #head(d,1); tail(d,1)
write_tsv(d, paste0("Table_lsbsr_seqkit.tsv"))


