rm(list = ls())
library(ggpubr) # ggscatterhist # install.packages("ggpubr")
#' - https://github.com/jasonsahl/LS-BSR/blob/master/manual.md
#' the gene screen method with TBLASTN
#' $prefix_bsr_matrix.txt: This is the 2x2 matrix of the BSR value for each CDS in each genome queried
filename <- "lsbsr_g_bsr_matrix.txt"
d <- read.delim(file=filename, quote="", row.names=1, na.strings="-", check.names=FALSE)
dim(d)
accession <- sub("\\.fna$", "", colnames(d))
colnames(d) <- accession
sum_BSR <- apply(d, 2, sum) # Sum of BSR values
nBSRgt0 <- apply(d > 0, 2, sum) # Number of genes with BSR values greater than zero
meanBSR <- sum_BSR / nBSRgt0
nrow(d)/2; TF <- nBSRgt0 > nrow(d)/2; summary(TF); 100*sum(TF)/length(TF)
d.f <- data.frame(accession, nBSRgt0, meanBSR); summary(d.f)
d.f <- d.f[order(d.f$nBSRgt0, d.f$meanBSR, decreasing=TRUE),]
# Exporting Data
write.table(d.f, file="Table_lsbsr_g_BN000925_RK2_BSR.tsv", sep="\t", quote=FALSE, row.names=FALSE)

ggscatterhist(
  d.f, x = "nBSRgt0", y = "meanBSR",
  color = "black", shape = 16, size = 1.6,
  xlab = "Number of genes with BSR values greater than zero",
  ylab = "Mean BSR value",
  margin.plot = "histogram",
  margin.params = list(fill = "black", color = "black")
)

# Number of genomes with BSR > 0
number_genomes <- apply(d > 0, 1, sum)
names(number_genomes) <- gsub("lcl\\|", "", names(number_genomes))
df_number_genomes <- data.frame(identifier = names(number_genomes), number_genomes = number_genomes)
# .faa
library(seqinr)
filename <- "BN000925.faa"
faa.seqs <- read.fasta(file = filename, seqtype="AA", strip.desc=TRUE)
Length <- getLength(faa.seqs)
Annotation <- gsub("lcl\\|", "", unlist(getAnnot(faa.seqs)))
gene <- sub(pattern=".+\\[gene=([^\\[]+)\\] \\[.+", replacement="\\1", Annotation)
df_faa <- data.frame(gene, Length, Annotation) # Creates data frame (table)
df_faa$identifier <- sub(" .*", "", Annotation)
#View(df_faa)
out <- merge(df_number_genomes, df_faa, by.x = "identifier", by.y = "identifier", all = TRUE)
out <- out[order(number_genomes,decreasing=TRUE),]
dim(out) #View(out)
# Exporting Data
write.table(out, file="Table_lsbsr_g_BN000925_RK2_number_genomes.tsv", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
#write.csv(out, file="Table_lsbsr_g_BN000925_RK2_number_genomes.csv", quote=TRUE, row.names=TRUE)

sessionInfo()
Sys.time()
