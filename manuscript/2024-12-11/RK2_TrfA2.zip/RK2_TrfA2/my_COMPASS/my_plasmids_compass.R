# rm(list = ls())
library(tidyverse)
#' - ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS
url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/plasmids.txt"
filename <- basename(url) # filename <- "plasmids.txt" # 3.0M
if(!file.exists(filename)) download.file(url = url, destfile = filename)
#d <- read_tsv(file=filename)
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)
dim(d); #colnames(d); head(d, n=1); tail(d, n=1)
#tail(d[,c("RefSeq", "INSDC")])
d$`RefSeq_` <- str_replace_all(string=d$`RefSeq`, pattern="\\.[0-9]", replacement="")
d$`INSDC_` <- str_replace_all(string=d$`INSDC`, pattern="\\.[0-9]", replacement="")
tail(d[,c("RefSeq_", "INSDC_")])
d <- na.omit(d[, c("RefSeq_", "INSDC_")]); dim(d)
conversion_RefSeq2INSDC <- setNames(d$INSDC_, d$RefSeq_)
head(conversion_RefSeq2INSDC)

#' - https://github.com/itsmeludo/COMPASS
url <- "https://raw.githubusercontent.com/itsmeludo/COMPASS/master/data/COMPASS.tsv"
filename <- basename(url) # filename <- "COMPASS.tsv" # 3.0 MB
if(!file.exists(filename)) download.file(url = url, destfile = filename)
d <- read_tsv(file=filename)
dim(d); #colnames(d); head(d, n=1); tail(d, n=1)
d$`RefSeq_INSDC` <- str_replace_all(string=d$`Accession`, pattern="\\.[0-9]", replacement="")
d$`RefSeq_INSDC` <- ifelse(d$`RefSeq_INSDC` %in% names(conversion_RefSeq2INSDC), conversion_RefSeq2INSDC[d$`RefSeq_INSDC`], d$`RefSeq_INSDC`)
out <- select(d, RefSeq_INSDC, Accession, `REP types`, Description)
write_tsv(out, "R.plasmids_compass.tsv")

sessionInfo()
Sys.time()
