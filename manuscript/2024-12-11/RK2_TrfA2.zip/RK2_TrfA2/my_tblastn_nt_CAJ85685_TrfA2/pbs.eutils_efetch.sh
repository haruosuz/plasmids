#!/usr/bin/bash
#PBS -q small
#PBS -l mem=8GB
#PBS -N pbs.eutils_efetch.sh
set -euo pipefail

cd ${PBS_O_WORKDIR}

echo; echo "[$(date)] $0 job has been started."

# extension
ext=faa; rettype=fasta_cds_aa
ext=ffn; rettype=fasta_cds_na
ext=fna; rettype=fasta
#ext=gbk; rettype=gbwithparts
echo; echo "[$(date)] Getting data ext=${ext} rettype=${rettype} using E-utilities"
mkdir -p "data/${ext}"
ACCESSIONs=(`cat "${AC}"`)
echo ${#ACCESSIONs[@]}
echo ${ACCESSIONs[@]}
for ACCESSION in ${ACCESSIONs[@]}; do
    if [ -e "data/${ext}/$ACCESSION.${ext}" ]; then continue; fi
    echo "[$(date)] $ACCESSION"
    wget -O "data/${ext}/$ACCESSION.${ext}" "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=$ACCESSION&rettype=${rettype}&retmode=text";
    sleep 1
done

echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

# Download data with accessions listed in the file.
ACCESSION=my_accession.txt
qsub -v AC="${ACCESSION}" pbs.eutils_efetch.sh
qstat -u $(whoami)

#__COMMENT_OUT__
