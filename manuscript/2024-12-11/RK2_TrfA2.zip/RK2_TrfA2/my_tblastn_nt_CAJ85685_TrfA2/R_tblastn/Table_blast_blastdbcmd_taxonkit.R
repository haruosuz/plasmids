Sys.time()
# rm(list = ls())
library(tidyverse)
#' - [10 Tibbles | R for Data Science](https://r4ds.had.co.nz/tibbles.html)
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns
#' - https://www.ncbi.nlm.nih.gov/books/NBK569853/ Extracting data from BLAST databases with blastdbcmd
#' - https://www.ncbi.nlm.nih.gov/books/NBK279684/table/appendices.T.blastdbcmd_application_opti/ outfmt
#' - https://www.ncbi.nlm.nih.gov/books/NBK53758/ NCBI Taxonomy
#' - https://bioinf.shenwei.me/taxonkit/usage/

filename <- "my_join_taxonkit_blastdbcmd.txt"
column_names <- c("taxid", "taxonomic_lineage", "accession", "sequence_length", "sequence_title")
d <- read_tsv(file = filename, col_names = column_names, comment = "#"); dim(d); head(d); tail(d)
d.t <- d

filename <- "tblastn-nt-CAJ85685.fasta.txt"
#filename <- "blastp-nr-CAJ85685.fasta.txt"
column_names <- c("query id", "subject id", "% identity", "alignment length", "mismatches", "gap opens", "q. start", "q. end", "s. start", "s. end", "evalue", "bit score", "% query coverage per subject")
d <- read_tsv(file = filename, col_names = column_names, comment = "#"); dim(d); head(d); tail(d)
if(grepl(pattern="tblastn", x=filename)) d <- d %>% mutate(accession = str_extract(`subject id`, "(?<=\\|)[A-Z]{1,2}\\d{5,6}\\.\\d{1,2}(?=\\|)"))
if(grepl(pattern="blastp", x=filename)) d <- d %>% mutate(accession = str_extract(`subject id`, "(?<=\\|)[A-Z0-9_]+\\.\\d+(?=\\|)"))
d.b <- d
#head(d$`subject id`); tail(d$`subject id`)

d <- full_join(x=d.b, y=d.t, by=c("accession" = "accession")); dim(d); #head(d,1); tail(d,1)
d %>% filter(is.na(evalue)) %>% head

write_tsv(d, paste0("Table_",filename,".tsv"), na = "")
