#!/usr/bin/bash
#PBS -q small
#PBS -l mem=96GB
#PBS -N pbs.sh
set -euo pipefail

cd ${PBS_O_WORKDIR}

# start
echo; echo "[$(date)] $0 job has been started."

# fasta
DIRECTORY=$PWD/data/fna
#find $DIRECTORY -name "*.fna" | xargs basename -s .fna | xargs -I{} ln -s $DIRECTORY/{}.fna $DIRECTORY/{}.fasta
find $DIRECTORY -name "*.fna.fasta" | xargs -I{} rm {}
find $DIRECTORY -name "*.fna" | xargs -I{} ln -s {} {}.fasta
#find $DIRECTORY -name "*.fna" | xargs -I{} cp {} {}.fasta

# module
source /etc/profile.d/modules.sh
#module avail R
module load R/4.0.3
module list

echo; echo "[$(date)] Run the gene screen method with tblastn:"
time bash ./scripts/run_lsbsr_g.sh $DIRECTORY
Rscript --vanilla ./scripts/my_lsbsr_g.R

#echo; echo "[$(date)] Run the de novo gene prediction method:"
#time bash ./scripts/run_lsbsr_c.sh $DIRECTORY
#Rscript --vanilla ./scripts/my_lsbsr_c.R

# done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'
https://biaswiki.nibb.ac.jp/menu/index.php

qsub pbs.sh
qstat -u $(whoami)

#__COMMENT_OUT__
