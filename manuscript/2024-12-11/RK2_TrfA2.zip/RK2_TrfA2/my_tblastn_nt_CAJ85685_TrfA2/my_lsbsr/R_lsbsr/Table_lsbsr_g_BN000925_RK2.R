rm(list = ls())
#' - https://github.com/jasonsahl/LS-BSR/blob/master/manual.md
#' the gene screen method with TBLASTN
#' $prefix_bsr_matrix.txt: This is the 2x2 matrix of the BSR value for each CDS in each genome queried
filename <- "lsbsr_g_bsr_matrix.txt"
d <- read.delim(file=filename, quote="", row.names=1, na.strings="-", check.names=FALSE)
dim(d)
my_pattern <- "BK037425|JX469824|KM655308|KM655309|KM655310|KM655311|MG692708|MT868884" # "partial\|contig"
TF <- grepl(pattern=my_pattern, x=colnames(d)); summary(TF); #d <- d[,!TF]
dim(d)
accession <- gsub(pattern="^([^\\.]+)(\\.[0-9])*\\.fna", replacement="\\1", x=colnames(d))
colnames(d) <- accession
which(grepl(pattern="CAJ85684", x=rownames(d))) # 21 # TrfA1
which(grepl(pattern="CAJ85685", x=rownames(d))) # 22 # TrfA2
which(grepl(pattern="CAJ85725", x=rownames(d))) # 61 # TraI
TF <- grepl(pattern="AY540995", x=colnames(d)); d[c(21,22,61),TF] # pEST4011
TF <- grepl(pattern="FP475957", x=colnames(d)); d[c(21,22,61),TF] # pTHI
TF <- grepl(pattern="CR522871", x=colnames(d)); d[c(21,22,61),TF] # Desulfotalea psychrophila LSv54, large plasmid
x <- t(d)[,21] # BSR values for TrfA1
x <- t(d)[,22] # BSR values for TrfA2
TF <- x == 1; sum(TF); paste0(names(x[TF]),collapse="|")
y <- t(d)[,61] # BSR values for TraI
TF <- y == 0; sum(TF); paste0(names(y[TF]),collapse="|")
plot(x, y, xlim=c(0,1), ylim=c(0,1), xlab="BSR_TrfA", ylab="BSR_TraI")
cor(x, y, method="spearman")
#heatmap(t(as.matrix(d)), scale="none", margins=c(6,1), cexRow=1, cexCol=1/3, col=rev(gray.colors(12)), main="Heatmap")
#d <- ifelse(d > 0, 1, 0) # Convert the BSR value to binary code (1/0) indicating gene presence/absence
sum_BSR <- apply(d, 2, sum) # Sum of BSR values
nBSRgt0 <- apply(d > 0, 2, sum) # Number of genes with BSR values greater than 0 (i.e., detected in the genome)
#
summary(sum_BSR)
summary(nBSRgt0)
nrow(d)/2; TF <- nBSRgt0 > nrow(d)/2; summary(TF)
TF <- grepl(pattern="CP000451", x=colnames(d)); sum_BSR[TF]; nBSRgt0[TF] # Nitrosomonas eutropha C91 plasmid p1
TF <- grepl(pattern="FP475957", x=colnames(d)); sum_BSR[TF]; nBSRgt0[TF] # pTHI
TF <- grepl(pattern="CR522871", x=colnames(d)); sum_BSR[TF]; nBSRgt0[TF] # Desulfotalea psychrophila LSv54, large plasmid
#barplot(sort(nBSRgt0), horiz=TRUE, names.arg=NA); #abline(v=nrow(d)/2, col="red", lty=2)
#d.f. <- data.frame(sum_BSR, nBSRgt0)
# histograms and correlations for a data matrix
#install.packages("psych") #library(psych)
#psych::pairs.panels(d.f., smooth=F,density=F,ellipses=F, breaks=0:nrow(d))
#plot(sum_BSR, nBSRgt0, xlab="sum(BSR)", ylab="sum(BSR>0)")
plot(sum_BSR, nBSRgt0, xlab="sum_BSR", ylab="nBSRgt0")
cor(sum_BSR, nBSRgt0, method="pearson")
cor(sum_BSR, nBSRgt0, method="spearman")
#abline(h = max(nBSRgt0)/2)
# 
plot(sum_BSR, nBSRgt0, xlab="sum(BSR)", ylab="sum(BSR>0)", type="n")
TF <- x < 1
points(sum_BSR[TF], nBSRgt0[TF], pch="+")
points(sum_BSR[!TF], nBSRgt0[!TF], pch="o", col="blue")
abline(h = max(nBSRgt0)/2)
# 
plot(sum_BSR, nBSRgt0, xlab="sum(BSR)", ylab="sum(BSR>0)", type="n")
TF <- y > 0
points(sum_BSR[TF], nBSRgt0[TF], pch="+")
points(sum_BSR[!TF], nBSRgt0[!TF], pch="o", col="red")
abline(h = max(nBSRgt0)/2)
# 
cor(sum_BSR, nBSRgt0, method="spearman")

d.f <- data.frame(accession, sum_BSR, nBSRgt0)
d.f <- d.f[order(d.f$sum_BSR, decreasing=TRUE),]
# Exporting Data
write.table(d.f, file="R.lsbsr_g_bsr_matrix.tsv", sep="\t", quote=FALSE, row.names=FALSE)

library(ggpubr) # install.packages("ggpubr")
ggscatterhist(d.f, x = "sum_BSR", y = "nBSRgt0",
              color = "black",
              #xlab = "sum_BSR", ylab = "nBSRgt0",
              xlab = "Sum of the BSR values", ylab = "Number of genes with BSR values > 0",
              margin.plot = "histogram",
              margin.params = list(fill = "black", color = "black"))

# Number of genomes with BSR > 0
number_genomes <- apply(d > 0, 1, sum)
names(number_genomes) <- gsub("lcl\\|", "", names(number_genomes))
df_number_genomes <- data.frame(identifier = names(number_genomes), number_genomes = number_genomes)
# .faa
library(seqinr)
filename <- "BN000925.faa"
faa.seqs <- read.fasta(file = filename, seqtype="AA", strip.desc=TRUE)
length(faa.seqs) # Get the number of elements
Length <- getLength(faa.seqs)
Annotation <- unlist(getAnnot(faa.seqs))
Annotation <- gsub("lcl\\|", "", Annotation)
gene <- sub(pattern=".+\\[gene=([^\\[]+)\\] \\[.+", replacement="\\1", Annotation)
d.f <- data.frame(gene, Length, Annotation) # Creates data frame (table)
d.f$identifier <- sub(" .*", "", Annotation)
#View(d.f)
out <- merge(df_number_genomes, d.f, by.x = "identifier", by.y = "identifier", all = TRUE)
out <- out[order(number_genomes,decreasing=TRUE),]
#View(out)
# Exporting Data
write.table(out, file="Table_lsbsr_g_BN000925_RK2_number_genomes.tsv", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
#write.csv(out, file="Table_lsbsr_g_BN000925_RK2_number_genomes.csv", quote=TRUE, row.names=TRUE)

sessionInfo()
Sys.time()
