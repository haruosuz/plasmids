#update.packages(ask=FALSE)
library(ggplot2)

d <- read.table("../my_sequence_length_only.txt", col.names = "sequence_length")

ggplot(d, aes(x = sequence_length)) + theme_bw() +
  geom_histogram(aes(y = after_stat(count)), binwidth = 5) +
  labs(x = "Sequence length", y = "Number of sequences") # title = "Histogram of Sequence Lengths"
