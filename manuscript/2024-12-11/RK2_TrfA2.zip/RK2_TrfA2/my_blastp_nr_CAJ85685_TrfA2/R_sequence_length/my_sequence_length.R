rm(list = ls())
#update.packages(ask=FALSE)
library(tidyverse)
library(EnvStats) #install.packages("EnvStats") #example(stat_n_text)
#' - https://github.com/haruosuz/books/tree/master/r4ds
#' - https://r4ds.had.co.nz/tibbles.html
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns

# Loading Data into R
filename <- "my_sequence_length.txt"
d <- read_tsv(file=filename, col_names = FALSE)

# Inspecting and Manipulating Data
str(d)
dim(d)
colnames(d)
colnames(d) <- c("taxonomy", "sequence_length")
colnames(d)
head(d, n=1)
tail(d, n=1)

#' - https://kazutan.github.io/kazutanR/stringr-intro.html
ss <- str_split(string=d$`taxonomy`, pattern=";", n=2, simplify=TRUE); head(ss); d$`Kingdom` <- ss[,1]

#' - https://r4ds.had.co.nz/transform.html
d %>% group_by(`Kingdom`) %>% summarise(n())

myL <- d %>% group_by(`Kingdom`) %>% summarise(
  count = n(),
  Lmin = min(`sequence_length`, na.rm = TRUE),
  Lmedian = median(`sequence_length`, na.rm = TRUE),
  Lmax = max(`sequence_length`, na.rm = TRUE)
)
myL

#' - https://readr.tidyverse.org/reference/write_delim.html
#write_csv(d, "R..csv.gz")
#write_tsv(d, "R..tsv.gz")

#' Exploring Data Visually
#' [7 Exploratory Data Analysis](https://r4ds.had.co.nz/exploratory-data-analysis.html)
#' 
#' <img src="https://d33wubrfki0l68.cloudfront.net/153b9af53b33918353fda9b691ded68cd7f62f51/5b616/images/eda-boxplot.png" alt="" width=50%>
#' 
#' - [3.3 Aesthetic mappings](https://r4ds.had.co.nz/data-visualisation.html#aesthetic-mappings)
#' - [3.8 Position adjustments](https://r4ds.had.co.nz/data-visualisation.html#position-adjustments)
# geom_bar
ggplot(data = d) + geom_bar(mapping = aes(x = `Kingdom`))

# https://r4ds.had.co.nz/exploratory-data-analysis.html
# geom_histogram
#ggplot(d, aes(x = `sequence_length`)) + geom_histogram() #+ ggtitle("histogram") 
#ggplot(d, aes(x = `sequence_length`, y = ..density..)) + geom_histogram()
#ggplot(d, aes(x = `sequence_length`)) + geom_histogram() + facet_wrap(~ `Kingdom`, ncol = 1)
#ggplot(d, aes(x = `sequence_length`, y = ..density..)) + geom_histogram() + facet_wrap(~ `Kingdom`, ncol = 1)

ggplot(d, aes(x = `sequence_length`)) + theme_bw() +
  geom_histogram(aes(y = ..count..), binwidth = 5) +
  labs(x = "Sequence length", y = "Number of sequences") # title = "Histogram of Sequence Lengths"

# geom_boxplot
#ggplot(d, aes(x = `Kingdom`, y = `sequence_length`)) + geom_boxplot() #+ facet_wrap(~ Kingdom)
#ggplot(data = d) + geom_boxplot(mapping = aes(x = reorder(`Kingdom`, `sequence_length`, FUN = median), y = `sequence_length`)) + coord_flip() + xlab("Kingdom")
#ggplot(d, aes(x=`Kingdom`, y=`sequence_length`)) + geom_boxplot() + stat_n_text(angle=30, size=4.0)

my_group <- 'Kingdom'
my_value <- 'sequence_length'
p1 <- ggplot(data = d, aes(x=reorder(!!sym(my_group), !!sym(my_value), FUN = median), y=!!sym(my_value))) + 
  geom_boxplot() + coord_flip() + labs(x=my_group, y=my_value) + stat_n_text(angle=0, size=4)
plot(p1)
#ggsave(paste0("R.geom_boxplot.",my_value,".pdf"), p1, width=4, height=4)

sessionInfo()
Sys.time()
Sys.Date()
