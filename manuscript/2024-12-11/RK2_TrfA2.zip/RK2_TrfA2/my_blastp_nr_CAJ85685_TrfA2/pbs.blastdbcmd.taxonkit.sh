#!/usr/bin/bash
#PBS -q small
#PBS -l mem=16GB
#PBS -N pbs.blastdbcmd.taxonkit.sh
set -e
#set -u
set -o pipefail

cd ${PBS_O_WORKDIR}

# start
echo; echo "[$(date)] $0 job has been started."

# module
source /etc/profile.d/modules.sh
module load blast+
module list
#blastdbcmd -help

blastdbcmd -version
cat "${AC}" | blastdbcmd -db "${DB}" -entry_batch -  -outfmt "%a|%T|%l|%t" | tr "|" "\t" > my_blastdbcmd.accession.taxid.sequence_length.sequence_title.txt
#cat "${AC}" | blastdbcmd -db "${DB}" -entry_batch -  -outfmt "%a|%K|%B|%L|%S|%T|%l|%t" | tr "|" "\t" > my_blastdbcmd.txt

# [cp-support:25836] 
source /home/haruo/miniconda3/etc/profile.d/conda.sh
conda activate base

#/home/haruo/miniconda3/bin/taxonkit
#taxonkit
#taxonkit --help
#taxonkit lineage --help
taxonkit version
cut -f2 my_blastdbcmd.accession.taxid.sequence_length.sequence_title.txt | taxonkit lineage > my_taxonkit.txt
#cat "${AC}" | blastdbcmd -db "${DB}" -entry_batch -  -outfmt "%T" | taxonkit lineage > my_taxonkit.txt

wc -l my_*.txt

# done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

ACCESSION=my_accession.txt
DATABASE=/bio/db/fasta/nr/nr
DATABASE=/bio/db/fasta/nt/nt
qsub -v AC="${ACCESSION}",DB="${DATABASE}" pbs.blastdbcmd.taxonkit.sh
qstat -u $(whoami)

#__COMMENT_OUT__

