#!/usr/bin/bash
set -e
set -u
set -o pipefail
#set -euo pipefail

# start
echo; echo "[$(date)] $0 job has been started."

echo $PWD
# Print operating system characteristics
uname -a

# module
#source /etc/profile.d/modules.sh
#module avail blast
#module display blast+
#module load blast+
#module list

# Variables and Command Arguments
PROGRAM=$1
QUERY=$2
DB=$3
EVALUE=$4
NAME=${PROGRAM}-$(basename $DB)-$(basename $QUERY)
OUT=${NAME}.txt
#SEQ=${NAME}.fasta

${PROGRAM} -version

# Building a BLAST database with local sequences
if test ${PROGRAM} = "blastp" || test ${PROGRAM} = "blastx" ; then
 DBTYPE=prot
elif test ${PROGRAM} = "blastn" || test ${PROGRAM} = "tblastn" ; then
 DBTYPE=nucl
else
 DBTYPE=nucl
fi
#makeblastdb -in $DB -dbtype $DBTYPE -hash_index -parse_seqids

echo; echo "[$(date)] Running ${PROGRAM}"
CMD="($PROGRAM -db $DB -query $QUERY -out $OUT \
 -evalue $EVALUE \
 -max_target_seqs 9999999 \
 -max_hsps 999 \
 -qcov_hsp_perc 0 \
 -outfmt '7 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qcovs' \
 -num_threads $(getconf _NPROCESSORS_ONLN)
)"
echo "CMD=$CMD"
eval $CMD

#echo; echo "[$(date)] Extracting data from BLAST databases with blastdbcmd"
#grep -v "^#" "${OUT}" | awk '{ print $2 }' | sort -u | blastdbcmd -db $DB -entry_batch - > $SEQ

#tmpfile=`mktemp $SEQ-header.XXXXXX`; grep '^>' $SEQ | tee $tmpfile

# Done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'
 -max_target_seqs $nDB \
#-max_target_seqs $(grep -c '^>' $DB) \
#-max_target_seqs 1 \

#-use_sw_tback \

# 6 = Tabular, 7 = Tabular with comment lines,
#-outfmt 7 \
#-outfmt "6 qseqid sseqid qcovs qcovhsp qcovus" \
#-outfmt "7 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qcovs qcovhsp qcovus" \

 -word_size 3 \

#__COMMENT_OUT__
