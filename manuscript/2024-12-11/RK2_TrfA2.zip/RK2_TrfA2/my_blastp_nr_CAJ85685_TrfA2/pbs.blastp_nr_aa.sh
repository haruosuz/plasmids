#!/usr/bin/bash
#PBS -q blast
#PBS -l mem=188GB
#PBS -N pbs.blastp_nr_aa.sh
set -e
#set -u
set -o pipefail
#set -euo pipefail

cd ${PBS_O_WORKDIR}

# start
echo; echo "[$(date)] $0 job has been started."

# module
source /etc/profile.d/modules.sh
module load blast+
module list

# Variables
PROGRAM=blastp

EVALUE=1e-03
#EVALUE=1e-20

# Database
DB=/bio/db/fasta/nr/nr
nDB=$(grep -c '^>' $DB)
echo; echo "[$(date)] There are ${nDB} entries in ${DB} database."

# Query
URL=http://togows.dbcls.jp/entry/protein/P78352.fasta # DLG4_HUMAN
URL=http://togows.dbcls.jp/entry/protein/CAJ85685.fasta # BN000925 | RK2 | complement(16521..17378) /note=" short form TrfA2, alternative start codon"

if [ ! -e $(basename ${URL}) ]; then wget "${URL}"; fi
QUERY=$(basename ${URL})
echo; echo "[$(date)] $PROGRAM $DB $QUERY"
time bash ./run_blast.sh $PROGRAM $QUERY $DB $EVALUE
NAME=${PROGRAM}-$(basename $DB)-$(basename $QUERY)
OUT=${NAME}.txt

grep -v "^#" ${OUT} | cut -f2 | cut -d"|" -f2 | cut -d"." -f1 | sort -u | grep "." > my_accession.${NAME}.txt
cp my_accession.${NAME}.txt my_accession.txt

# done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

qsub pbs.blastp_nr_aa.sh
qstat -u $(whoami)

#__COMMENT_OUT__
