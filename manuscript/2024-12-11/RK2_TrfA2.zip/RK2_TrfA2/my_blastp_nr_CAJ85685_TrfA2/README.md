Haruo Suzuki  
Last Update: 2024-03-23

----------

# tblastn_nt test project
Project started 2021-11-24.

Search NCBI nr (non-redundant) database using BLAST programs (tblastn, blastp, blastn). It may take several hours, depending on the job.

- [scripts](#scripts)
- [data](#data)
  - [database](#database)
  - [query](#query)
- [output](#output)
  - [blast output](#blast-output)
  - [accession](#accession)
- [post-blast scripts](#)
  - [blastdbcmd taxonkit](#)
  - [eutils](#eutils)
    - [pbs.eutils_efetch.sh](#pbs.eutils_efetch.sh)
    - [pbs.tblastn2eutils.sh](#pbs.tblastn2eutils.sh)
- [references](#references)

## project directories
```
./README.md
./scripts/my_sequence_length.R
./scripts/my_wordcloud.R
./scripts/pbs.blastdbcmd.taxonkit.sh
./scripts/pbs.blastn_nt_nt.sh
./scripts/pbs.blastp_nr_aa.sh
./scripts/pbs.eutils_efetch.sh
./scripts/pbs.psiblast_nr_aa.sh
./scripts/pbs.sh
./scripts/pbs.tblastn2eutils.sh
./scripts/pbs.tblastn_nt_aa.sh
./scripts/run_blast.sh
```

## scripts
`pbs.blastn_nt_nt.sh` performs BLASTN against NCBI nr-nt database.
`pbs.blastp_nr_aa.sh` performs BLASTP against NCBI nr-aa database.
`pbs.tblastn_nt_aa.sh` performs TBLASTN against NCBI nr-nt database.

To change BLAST E-value cutoff/threshold, edit the following lines in the scripts:
```
EVALUE=1e-03
#EVALUE=1e-20
```

Remove the hash `#` as needed (to extract complete plasmid sequences):
```
#cat my_blastdbcmd.accession.taxid.sequence_length.sequence_title.txt | grep -iv "Helper \|Synthetic construct \|vector" | awk -F "\t" -v OFS="\t" '$3 <= 223670 { print $0 }' | cut -f1 | cut -d"." -f1 | sort -u > my_accession.txt
```

Run the script using:
```
qsub pbs.blastn_nt_nt.sh
# or
qsub pbs.blastp_nr_aa.sh
# or
qsub pbs.tblastn_nt_aa.sh
```

qstat - display status of PBS batch jobs, queues, or servers
```
qstat -u $(whoami)
```

qdel - deletes PBS jobs
```
qdel `qselect -u $(whoami)`
```

## data
### database
https://biaswiki.nibb.ac.jp/menu/index.php/分子生物学データベース
```
# NCBI nr-nt	nt
ls -lh /bio/db/fasta/nt/nt
-r--r--r-- 1 ideas ideas 1.4T Dec 20 18:31 /bio/db/fasta/nt/nt

# NCBI nr-aa	nr
ls -lh /bio/db/fasta/nr/nr
-r--r--r-- 1 ideas ideas 313G Dec 20 02:46 /bio/db/fasta/nr/nr
```

### query

- https://www.ncbi.nlm.nih.gov/nuccore/BN000925 plasmid RK2
- https://www.ncbi.nlm.nih.gov/nuccore/U67194 Enterobacter aerogenes plasmid R751
- https://www.ncbi.nlm.nih.gov/nuccore/AY365053 Ralstonia eutropha JMP134 plasmid pJP4
- https://www.ncbi.nlm.nih.gov/nuccore/GU479466 Neisseria gonorrhoeae strain 5289 plasmid pEP5289
- https://www.ncbi.nlm.nih.gov/nuccore/KC241982 Canine circovirus isolate UCD1-1698

Query sequences used for BLAST search can be changed as follows:
```
# Query
URL=http://togows.dbcls.jp/entry/protein/P78352.fasta # DLG4_HUMAN
URL=https://rest.uniprot.org/uniprotkb/P78352.fasta # DLG4_HUMAN

URL=http://togows.dbcls.jp/entry/protein/AGI42838.fasta # KC241982 | Canine circovirus isolate UCD1-1698 | 1..912 /note="Rep" /product="putative replication associated protein"
URL=http://togows.dbcls.jp/entry/protein/AGI42839.fasta # KC241982 | Canine circovirus isolate UCD1-1698 | complement(1116..1928) /note="Cap" /product="putative capsid protein"

URL=http://togows.dbcls.jp/entry/protein/ADF36634.fasta # GU479466 | pEP5289 | complement(6730..8664) /product="TetM" /note="tetracyclin resistance protein"
URL=http://togows.dbcls.jp/entry/protein/ADF36658.fasta # GU479466 | pEP5289 | /product="TrfA" /note="oriV activator protein; plasmid replication" 
URL=http://togows.dbcls.jp/entry/protein/ADF36669.fasta # GU479466 | pEP5289 | 34447..36840 /product="TraI" /note="DNA relaxase"

URL=http://togows.dbcls.jp/entry/protein/AAR31035.fasta # AY365053 | pJP4 | complement(17688..19484) /gene="tfdBI" /product="2,4-dichlorophenol hydroxylase"
URL=http://togows.dbcls.jp/entry/protein/AAR31070.fasta # AY365053 | pJP4 | /gene="trfA1" /product="transreplication factor"
URL=http://togows.dbcls.jp/entry/protein/AAR31100.fasta # AY365053 | pJP4 | complement(83064..85304) /gene="traI" /product="relaxosome stabilization protein"

```

## output
The scripts such as `pbs.blastp_nr_aa.sh.` and  `pbs.tblastn_nt_aa.sh` generate output files, including:
```
blastp-nr-*.txt: BLASTP output (Tabular with comment lines)
tblastn-nt-*.txt: TBLASTN output (Tabular with comment lines)
my_accession*.txt: a list of ACCESSION numbers of subject sequneces
pbs.*.sh.{o,e}*: standard output (*.o) and standard error (*.e) files
```

Check the number of sequence entries in the BLAST databases. For example,
```
grep "entries" pbs.*.sh.o*
pbs.tblastn_nt_aa.sh.o*:[$(date)] There are 100962104 entries in /bio/db/fasta/nt/nt database.
pbs.blastp_nr_aa.sh.o*:[$(date)] There are 642035595 entries in /bio/db/fasta/nr/nr database.
```

### BLAST output
Inspect BLAST output
```
# count the number of High Scoring Pairs (HSP) in BLAST output
grep -c -v "^#" tblastn-nt-*.txt

# print BLAST output column labels:
grep "^# Fields" tblastn-nt-*.txt

# Fields: query id, subject id, % identity, alignment length, mismatches, gap opens, q. start, q. end, s. start, s. end, evalue, bit score, % query coverage per subject

# numbering the column labels

     1  # Fields: query id
     2   subject id
     3   % identity
     4   alignment length
     5   mismatches
     6   gap opens
     7   q. start
     8   q. end
     9   s. start
    10   s. end
    11   evalue
    12   bit score
    13   % query coverage per subject

```

Filter BLAST output; for example, extract only subject sequences with `evalue` <1e-3 and `% query coverage per subject` >60, and store their ACCESSION numbers in *my_accession.txt*:
```
OUT=tblastn-nt-Q08050.fasta.txt
grep -v "^#" "${OUT}" | awk '$11 < 1e-3 && $13 > 60 { print $2 }' | cut -d"|" -f4 | cut -d"." -f1 | sort -u > my_accession.txt

OUT=blastp-nr-AAC64439.fasta.txt
grep -v "^#" "${OUT}" | awk '$11 < 1e-3 && $13 > 60 { print $2 }' | cut -d"|" -f2 | cut -d"." -f1 | sort -u > my_accession.txt
```

### accession
Count the number of lines in each file:
```
wc -l my_accession*.txt
```

Performs set union, intersection, (asymmetric!) difference
```
FILE1=my_accession.${NAME1}.txt
FILE2=my_accession.${NAME2}.txt
cat ${FILE1} ${FILE2} | sort | uniq > my_accession.set_union.txt
cat ${FILE1} ${FILE2} | sort | uniq -d > my_accession.set_intersection.txt
cat ${FILE1} ${FILE2} ${FILE2} | sort | uniq -u > my_accession.set_difference12.txt
cat ${FILE1} ${FILE1} ${FILE2} | sort | uniq -u > my_accession.set_difference21.txt
```
https://www.johndcook.com/blog/2019/11/24/comm-set-theory/

## post-blast scripts
### blastdbcmd taxonkit
Extract data of subject sequences from BLAST databases with `blastdbcmd`, and
Retrieve taxonomic lineage of given TaxIds using `taxonkit` (NCBI Taxonomy Toolkit)

- https://github.com/haruosuz/bioinfo/blob/master/references/README.blast.md#blastdbcmd
- https://github.com/haruosuz/bioinfo/blob/master/2021/CaseStudy.md#taxonkit
https://bioinf.shenwei.me/taxonkit/usage/#lineage

https://bioinf.shenwei.me/taxonkit/usage/#before-use
```
wget -c ftp://ftp.ncbi.nih.gov/pub/taxonomy/taxdump.tar.gz 
tar -zxvf taxdump.tar.gz

mkdir -p $HOME/.taxonkit
cp names.dmp nodes.dmp delnodes.dmp merged.dmp $HOME/.taxonkit
```

Run the shell script *pbs.blastdbcmd.taxonkit.sh* with the input file *my_accession.txt* after the BLAST.
Submit the job with:
```
ACCESSION=my_accession.txt
DATABASE=/bio/db/fasta/nt/nt # after *pbs.tblastn_nt_aa.sh*
#DATABASE=/bio/db/fasta/nr/nr # after *pbs.blastp_nr_aa.sh*
ls "${ACCESSION}" "${DATABASE}" # Check if the files exist.
qsub -v AC="${ACCESSION}",DB="${DATABASE}" pbs.blastdbcmd.taxonkit.sh
```

The output file *my_taxonkit.txt* contains "TaxIds" and "Lineage" in tab-separated values (TSV).

Inspecting *my_taxonkit.txt* using:
```
cat my_taxonkit.txt | cut -f2 | cut -d";" -f1 | sort | uniq -c
cat my_taxonkit.txt | cut -f2 | cut -d";" -f1,2 | sort | uniq -c
cat my_taxonkit.txt | cut -f2 | cut -d";" -f1-3 | sort | uniq -c
```

The output file *my_blastdbcmd.accession.taxid.sequence_length.sequence_title.txt* contains the following tab-separated values (TSV):
```
blastdbcmd -help | less

                %a means accession
                %T means taxid
                %l means sequence length
                %t means sequence title
```

Combine information from *'my_taxonkit.txt'* and *'my_blastdbcmd.accession.taxid.sequence_length.sequence_title.txt'* files using the following commands to create *'my_join_taxonkit_blastdbcmd.txt'* file.
```
# Set variables
DIR="${PWD}"
FILE1="${DIR}/my_taxonkit.txt"
FILE2="${DIR}/my_blastdbcmd.accession.taxid.sequence_length.sequence_title.txt"

# Sorting and removing duplicates in 'my_taxonkit.txt'
sort -u "${FILE1}" | sort -k1,1 > my_sorted_taxonkit.txt

# Sorting and removing duplicates in 'my_blastdbcmd.accession.taxid.sequence_length.sequence_title.txt'
sort -u "${FILE2}" | sort -k2,2 > my_sorted_blastdbcmd.txt

# basic syntax: join -1 <file_1_field> -2 <file_2_field> <file_1> <file_2>
join -t$'\t' -1 1 -2 2 my_sorted_taxonkit.txt my_sorted_blastdbcmd.txt > my_join_taxonkit_blastdbcmd.txt

# If you receive a message like the following:
# join: my_sorted_blastdbcmd.txt:92034: is not sorted: prf 2208451A 70732 488 syntrophin [Torpedo sp.]
# Remove the problematic rows and create a new file 'my_blastdbcmd.txt' as follows:
grep -v "^prf[[:space:]][[:space:]]" "${FILE2}" > "${DIR}/my_blastdbcmd.txt"

# Retry with the newly created 'my_blastdbcmd.txt'
FILE2="${DIR}/my_blastdbcmd.txt"
sort -u "${FILE2}" | sort -k2,2 > my_sorted_blastdbcmd.txt
join -t$'\t' -1 1 -2 2 my_sorted_taxonkit.txt my_sorted_blastdbcmd.txt > my_join_taxonkit_blastdbcmd.txt

# Inspecting the 'my_join_taxonkit_blastdbcmd.txt' file
cat my_join_taxonkit_blastdbcmd.txt | cut -f2 | cut -d";" -f1 | sort | uniq -c
cat my_join_taxonkit_blastdbcmd.txt | cut -f2 | cut -d";" -f1,2 | sort | uniq -c
cat my_join_taxonkit_blastdbcmd.txt | cut -f2 | cut -d";" -f1-3 | sort | uniq -c | sort -n
```

The 'my_join_taxonkit_blastdbcmd.txt' is a tab-separated values (TSV) file that includes 5 columns representing the following information: TaxIds, Lineage, accession, sequence length, and sequence title.
```
cat my_join_taxonkit_blastdbcmd.txt | head -n 1 | tr "\t" "\n" | nl
     1  10
     2  cellular organisms;Bacteria;Pseudomonadota;Gammaproteobacteria;Cellvibrionales;Cellvibrionaceae;Cellvibrio
     3  WP_078044415.1
     4  205
     5  MULTISPECIES: guanylate kinase [Cellvibrio]
```
<https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id=10&mode=info>

Use `awk` to filter rows based on specified criteria, including the `taxonomic_lineage` filter, and excluding the `sequence_title` filter.
```
# Set the `taxonomic_lineage` filter, such as "cellular organisms" ("Bacteria", "Archaea", "Eukaryota"), "Viruses", etc.
# You can uncomment and set specific `taxonomic_lineage` values if needed.
taxonomic_lineage=".*"	# Default: Any character (regular expression ".*")
#taxonomic_lineage="cellular organisms"
#taxonomic_lineage="cellular organisms;Bacteria"
#taxonomic_lineage="cellular organisms;Archaea"
#taxonomic_lineage="cellular organisms;Eukaryota"
#taxonomic_lineage="Viruses"

# Set the `sequence_title` filter.
sequence_title="partial|unnamed protein product|hypothetical protein|[Uu]ncharacterized protein|[Vv]ector|synthetic|uncultured"
sequence_title="~~~"	# Default: A character string ("~~~") not expected to match anything.

# Extract rows where column 2 (taxonomic lineage) contains taxonomic groups specified by the 'taxonomic_lineage' variable, 
# and column 5 (sequence_title) is not annotated as characters specified by the 'sequence_title' variable, 
# and redirect it to the file 'my_join_taxonkit_blastdbcmd.awk.txt'.
cat my_join_taxonkit_blastdbcmd.txt | awk -F "\t" -v OFS="\t" '$2 ~ /'"$taxonomic_lineage"'/ && $5 !~ /'"$sequence_title"'/ { print $0 }' > my_join_taxonkit_blastdbcmd.awk.txt

# Extract the 3,4,5th columns (accession, sequence_length, sequence_title), sort them by sequence_length values, and print the top 10 largest and shortest sequences.
cat my_join_taxonkit_blastdbcmd.awk.txt | cut -f3,4,5 | sort -k2,2nr | (head -n 10; tail -n 10)

# Extract the 5th column (sequence_title), stream edit (sed) the text, and redirect it to the file 'my_join_taxonkit_blastdbcmd.awk.cut5.sed.txt'.
cat my_join_taxonkit_blastdbcmd.awk.txt | cut -f5 | sed -E 's/\[.+\]//; s/MULTISPECIES: //; s/MAG: //; s/.*TPA.*: //; s/PREDICTED: //; s/LOW QUALITY PROTEIN: //; s/ isoform .*//; s/, partial//; s/, putative//; s/putative //; s/RecName: Full=//; s/AltName: Full=//; s/\(//; s/\)//; s/;//; s/ $//; ' > my_join_taxonkit_blastdbcmd.awk.cut5.sed.txt

# Count occurrences and display the top 20 most abundant text.
cat my_join_taxonkit_blastdbcmd.awk.cut5.sed.txt | sort | uniq -c | sort -nr | head -n 20

# Disregard case differences: e.g., convert the text to uppercase using `tr '[:lower:]' '[:upper:]'`.
cat my_join_taxonkit_blastdbcmd.awk.cut5.sed.txt | tr '[:lower:]' '[:upper:]' | sort | uniq -c | sort -nr | head -n 20

# Reduce the length of the strings; e.g., extract the first two words using `cut -d" " -f1-2`.
cat my_join_taxonkit_blastdbcmd.awk.cut5.sed.txt | cut -d" " -f1-2 | tr '[:lower:]' '[:upper:]' | sort | uniq -c | sort -nr | head -n 20
```

Using the following commands to create the input file 'my_sequence_length.txt' for the R script 'my_sequence_length.R', where the R object `myL` contains summary statistics for the sequence_length of each taxonomic group (Kingdom: Archaea, Bacteria, Eukaryota, Viruses).
```
# Extract rows where column 2 (taxonomic lineage) contains any character (regular expression '.'),
# extract the first 2 taxonomic ranks separated by ";", and 
# redirect the output to create the file 'my_join.cut2.txt'
cat my_join_taxonkit_blastdbcmd.awk.txt | cut -f2 | sed -E 's/\[.+\]//; s/cellular organisms;//; ' | cut -d";" -f1-2 > my_join.cut2.txt

# Extract the 4th columns (sequence_length), and 
# redirect the output to create the file 'my_join.cut4.txt'
cat my_join_taxonkit_blastdbcmd.awk.txt | cut -f4 > my_join.cut4.txt

# Check if the two files have the same number of rows
wc -l my_join.cut*.txt

# Combine the files 'my_join.cut2.txt' and 'my_join.cut4.txt' to create the file 'my_sequence_length.txt'.
paste my_join.cut2.txt my_join.cut4.txt > my_sequence_length.txt

# The file 'my_sequence_length.txt' is expected to have 2 fields (columns).
awk -F "\t" '{print NF; exit}' my_sequence_length.txt 
2
```

Using the following commands to create the input files 'my_word_freq.*.tsv' for the R script 'my_wordcloud.R' where word frequencies are converted to ranks using `d$freq <- rank(d$freq)` for visualization purposes.
```
# Count the number of lines in the files
wc -l my_join_taxonkit_blastdbcmd.awk*.txt

# Display the values of the variables
echo $taxonomic_lineage
echo $sequence_title

# Create word frequency files ('my_word_freq.*.tsv') for taxonomic_lineage
# filename <- "my_word_freq.taxon1-2.tsv"
cat my_join_taxonkit_blastdbcmd.awk.txt | cut -f2 | sed -E 's/\[.+\]//; s/cellular organisms;//; ' | cut -d";" -f1-2 | sort | uniq -c | sort -nr | sed -E 's/^ +([0-9]+) (.+)$/\2\t\1/' > my_word_freq.taxon1-2.tsv

# filename <- "my_word_freq.taxon1-3.tsv"
cat my_join_taxonkit_blastdbcmd.awk.txt | cut -f2 | sed -E 's/\[.+\]//; s/cellular organisms;//; ' | cut -d";" -f1-3 | sort | uniq -c | sort -nr | sed -E 's/^ +([0-9]+) (.+)$/\2\t\1/' > my_word_freq.taxon1-3.tsv

# Create word frequency files ('my_word_freq.*.tsv') for sequence_title
# filename <- "my_word_freq.title1-.tsv"
cat my_join_taxonkit_blastdbcmd.awk.cut5.sed.txt | sort | uniq -c | sort -nr | sed -E 's/^ +([0-9]+) (.+)$/\2\t\1/' > my_word_freq.title1-.tsv

# filename <- "my_word_freq.title1-.upper.tsv"
cat my_join_taxonkit_blastdbcmd.awk.cut5.sed.txt | tr '[:lower:]' '[:upper:]' | sort | uniq -c | sort -nr | sed -E 's/^ +([0-9]+) (.+)$/\2\t\1/' > my_word_freq.title1-.upper.tsv

```

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2910039/
Figure 3. Word clouds 

### eutils
- https://github.com/haruosuz/bioinfo/blob/master/references/README.bioinfo.tools.md#e-utilities

Use NCBI E-utilities to download FASTA format files of nucleotide sequences.

#### pbs.eutils_efetch.sh
Use `pbs.eutils_efetch.sh` to download FASTA files of sequences with ACCESSION numbers stored in the `my_accession.txt` file.

Submit the job with:
```
ACCESSION=my_accession.txt
qsub -v AC="${ACCESSION}" pbs.eutils_efetch.sh
qstat -u $(whoami)
```

Inspect the downloaded FASTA files using the following commands:
```
# Count the number of FASTA files with the extension '*.fna'
find data/fna/ -type f -name "*.fna" | wc -l

# Count the number of FASTA headers that start with ">"
grep "^>" data/fna/*.fna | wc -l

# If the number of FASTA headers starting with ">" is less than the number of FASTA files,
# find and delete all empty files in the 'data/' directory
find data/ -type f -empty
find data/ -type f -empty -delete

# Rerun the script to download only the files that do not already exist
ACCESSION=my_accession.txt
qsub -v AC="${ACCESSION}" pbs.eutils_efetch.sh

```

#### pbs.tblastn2eutils.sh
Use `pbs.tblastn2eutils.sh` to download FASTA files using BLAST results (`tblastn.txt`) with columns for the subject ID (`subject id`), start position (`s. start`) and end position (`s. end`).
```
# Assign the BLAST results file name to the variable `OUT`
OUT="tblastn-nt-Q08050.fasta.txt"

# Display the file information using the `ls -lh` command
ls -lh "${OUT}"

# Filter the BLAST results based on specific criteria and save them to `tblastn.txt`
grep -v "^#" "${OUT}" | awk '$11 < 1e-165 && $13 > 60 { print $0 }' > tblastn.txt

# Submit a job using the `pbs.tblastn2eutils.sh` script
qsub pbs.tblastn2eutils.sh

# Check the status of the submitted job for the current user
qstat -u $(whoami)

# Display the first two lines of each file in the `data/fna/` directory
find data/fna/ -type f | xargs head -n 2
```

## references
- https://biaswiki.nibb.ac.jp/menu/index.php
  - <https://biaswiki.nibb.ac.jp/menu/images/2/24/3_PBS2022_en.pdf>
How to use PBS
- 
- https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ptme5
p.19
It is a basic assumption of phylogenetics that all sequences (or organisms) on a given tree are descended from a common ancestor. Indeed, in evolutionary studies the word homologous means “descended from a common ancestor.” This issue will be discussed in more detail in Chapter 3, but for the moment we will include only those sequences we can be confident are homologs of the query sequence; thus we will set the E value cutoff parameter at values <1e-3 (i.e., we will include on the tree only those sequences whose E value is <10–3). Likewise, we probably don’t want to include sequences that are homologous over just a small portion of the query. For this exercise we will only include sequences whose query coverage is ≥60%.
- 
- https://github.com/haruosuz/introBI/blob/master/2023-10/README.md#join
- https://github.com/haruosuz/introBI/blob/master/2023-10/README.md#using-pandoc-to-render-markdown-to-html
```
# Using Pandoc to Render Markdown to HTML
filename=README.md
pandoc --from markdown --to html ${filename} > ${filename}.html
```

----------







